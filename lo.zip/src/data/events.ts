import initialEventsData from "./events.json";

export interface BandMember {
  name: string;
  role: string;
  imageUrl: string;
}

export interface GameCharacter {
  name: string;
  imageUrl: string;
  phrase: string;
}

export interface TheaterCharacter {
  name: string;
  actor: string;
  imageUrl: string;
}

export interface FootballTeam {
  name: string;
  logoUrl: string;
  coach: string;
  coachImageUrl: string;
  captain: string;
  captainImageUrl: string;
}

// ─── Interfaces por categoría ───

export interface MusicEventItem {
  id: string;
  title: string;
  category: "music";
  date: string;
  location: string;
  description: string;
  youtubeId?: string;
  bandMembers?: BandMember[];
  price?: string;
  upcoming?: boolean;
  coverImage?: string;
}

export interface GameEventItem {
  id: string;
  title: string;
  category: "games";
  date: string;
  location?: string;
  description: string;
  price: string;
  pricePhysical?: string;
  youtubeTrailerId: string;
  carouselImages: string[];
  characters: GameCharacter[];
  upcoming?: boolean;
  preorder?: boolean;
  coverImage?: string;
}

export interface TheaterEventItem {
  id: string;
  title: string;
  category: "theatre";
  date: string;
  location: string;
  description: string;
  imageUrl: string;
  characters: TheaterCharacter[];
  price: string;
  upcoming?: boolean;
  coverImage?: string;
}

export interface FootballEventItem {
  id: string;
  title: string;
  category: "football";
  date: string;
  time: string;
  location: string;
  stadium: string;
  description: string;
  youtubeStreamId?: string;
  homeTeam: FootballTeam;
  awayTeam: FootballTeam;
  price: string;
  upcoming?: boolean;
  isLive?: boolean;
  coverImage?: string;
}

export type EventItem =
  | MusicEventItem
  | GameEventItem
  | TheaterEventItem
  | FootballEventItem;

const globalEventsKey = Symbol.for("shadow_events_data");
const g = globalThis as unknown as { [key: symbol]: EventItem[] };

if (!g[globalEventsKey]) {
  g[globalEventsKey] = [...(initialEventsData as EventItem[])];
}

export function getEvents(): EventItem[] {
  return g[globalEventsKey];
}

export function getEventById(id: string): EventItem | undefined {
  return g[globalEventsKey].find((e) => e.id === id);
}

export function getEventsByCategory(category: string): EventItem[] {
  if (!category || category === "all") return g[globalEventsKey];
  return g[globalEventsKey].filter((e) => e.category === category);
}

export function getUpcomingEvents(category?: string): EventItem[] {
  const filtered = g[globalEventsKey].filter((e) => e.upcoming === true);
  if (!category || category === "all") return filtered;
  return filtered.filter((e) => e.category === category);
}

export function getCurrentEvents(category?: string): EventItem[] {
  const filtered = g[globalEventsKey].filter((e) => !e.upcoming);
  if (!category || category === "all") return filtered;
  return filtered.filter((e) => e.category === category);
}

export function addEvent(event: EventItem): void {
  g[globalEventsKey].unshift(event);
}

export function updateEvent(id: string, updated: Partial<EventItem>): boolean {
  const index = g[globalEventsKey].findIndex((e) => e.id === id);
  if (index !== -1) {
    g[globalEventsKey][index] = { ...g[globalEventsKey][index], ...updated } as EventItem;
    return true;
  }
  return false;
}

export function deleteEvent(id: string): boolean {
  const index = g[globalEventsKey].findIndex((e) => e.id === id);
  if (index !== -1) {
    g[globalEventsKey].splice(index, 1);
    return true;
  }
  return false;
}

export const eventsData: EventItem[] = g[globalEventsKey];