import initialCategories from "./categories.json";

export interface CategoryItem {
  id: string;
  name: string;
  slug: string;
  description?: string;
  icon?: string;
}

const globalCategoriesKey = Symbol.for("shadow_categories_data");
const g = globalThis as unknown as { [key: symbol]: CategoryItem[] };

if (!g[globalCategoriesKey]) {
  g[globalCategoriesKey] = [...(initialCategories as CategoryItem[])];
}

export function getCategories(): CategoryItem[] {
  return g[globalCategoriesKey];
}

export function getCategoryBySlug(slug: string): CategoryItem | undefined {
  return g[globalCategoriesKey].find((c) => c.slug === slug || c.id === slug);
}

export function addCategory(category: CategoryItem): void {
  g[globalCategoriesKey].push(category);
}

export function updateCategory(id: string, updated: Partial<CategoryItem>): boolean {
  const index = g[globalCategoriesKey].findIndex((c) => c.id === id || c.slug === id);
  if (index !== -1) {
    g[globalCategoriesKey][index] = { ...g[globalCategoriesKey][index], ...updated };
    return true;
  }
  return false;
}

export function deleteCategory(id: string): boolean {
  const index = g[globalCategoriesKey].findIndex((c) => c.id === id || c.slug === id);
  if (index !== -1) {
    g[globalCategoriesKey].splice(index, 1);
    return true;
  }
  return false;
}

export const categoriesData = g[globalCategoriesKey];