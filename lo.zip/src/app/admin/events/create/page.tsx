"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { categoriesData } from "@/data/categories";
import type { GameCharacter, BandMember, TheaterCharacter, FootballTeam } from "@/data/events";

export default function CreateEventPage() {
  const router = useRouter();

  // Campos Generales
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("music");
  const [date, setDate] = useState("");
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [coverImage, setCoverImage] = useState("");
  const [upcoming, setUpcoming] = useState(false);

  // Campos Específicos de Videojuegos
  const [youtubeTrailerId, setYoutubeTrailerId] = useState("");
  const [pricePhysical, setPricePhysical] = useState("");
  const [carouselImages, setCarouselImages] = useState<string[]>([
    "https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?w=1200",
    "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200",
    "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=1200",
    "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=1200",
    "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1200"
  ]);
  const [gameCharacters, setGameCharacters] = useState<GameCharacter[]>([
    { name: "Link", imageUrl: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=200", phrase: "¡Hyaaah! ¡El coraje de la Trifuerza nunca se extingue!" },
    { name: "Zelda", imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200", phrase: "El destino de Hyrule descansa en tus manos." }
  ]);

  // Campos Específicos de Música
  const [musicYoutubeId, setMusicYoutubeId] = useState("");
  const [bandMembers, setBandMembers] = useState<BandMember[]>([
    { name: "Vocalista", role: "Voz Principal", imageUrl: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=200" },
    { name: "Guitarrista", role: "Guitarra Solista", imageUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200" }
  ]);

  // Campos Específicos de Teatro
  const [theaterImage, setTheaterImage] = useState("");
  const [theaterCharacters, setTheaterCharacters] = useState<TheaterCharacter[]>([
    { name: "Protagonista", actor: "Actor Principal", imageUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200" }
  ]);

  // Campos Específicos de Fútbol
  const [stadium, setStadium] = useState("");
  const [matchTime, setMatchTime] = useState("6:10 PM");
  const [youtubeStreamId, setYoutubeStreamId] = useState("live_stream_id");
  const [homeTeam, setHomeTeam] = useState<FootballTeam>({
    name: "Equipo Local",
    logoUrl: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=200",
    coach: "Director Técnico Local",
    coachImageUrl: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=200",
    captain: "Capitán Local",
    captainImageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200",
  });
  const [awayTeam, setAwayTeam] = useState<FootballTeam>({
    name: "Equipo Visitante",
    logoUrl: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=200",
    coach: "Director Técnico Visitante",
    coachImageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200",
    captain: "Capitán Visitante",
    captainImageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Manejadores Carrusel
  const handleCarouselChange = (index: number, val: string) => {
    const updated = [...carouselImages];
    updated[index] = val;
    setCarouselImages(updated);
  };

  // Manejadores Personajes Juegos
  const handleGameCharacterChange = (index: number, field: keyof GameCharacter, val: string) => {
    const updated = [...gameCharacters];
    updated[index] = { ...updated[index], [field]: val };
    setGameCharacters(updated);
  };
  const addGameCharacter = () => {
    setGameCharacters([...gameCharacters, { name: "", imageUrl: "", phrase: "" }]);
  };
  const removeGameCharacter = (index: number) => {
    setGameCharacters(gameCharacters.filter((_, i) => i !== index));
  };

  // Manejadores Música
  const handleBandMemberChange = (index: number, field: keyof BandMember, val: string) => {
    const updated = [...bandMembers];
    updated[index] = { ...updated[index], [field]: val };
    setBandMembers(updated);
  };
  const addBandMember = () => {
    setBandMembers([...bandMembers, { name: "", role: "", imageUrl: "" }]);
  };
  const removeBandMember = (index: number) => {
    setBandMembers(bandMembers.filter((_, i) => i !== index));
  };

  // Manejadores Teatro
  const handleTheaterCharacterChange = (index: number, field: keyof TheaterCharacter, val: string) => {
    const updated = [...theaterCharacters];
    updated[index] = { ...updated[index], [field]: val };
    setTheaterCharacters(updated);
  };
  const addTheaterCharacter = () => {
    setTheaterCharacters([...theaterCharacters, { name: "", actor: "", imageUrl: "" }]);
  };
  const removeTheaterCharacter = (index: number) => {
    setTheaterCharacters(theaterCharacters.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const payload: any = {
        title,
        category,
        date,
        location,
        description,
        price,
        coverImage: coverImage || "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800",
        upcoming,
      };

      if (category === "games") {
        payload.youtubeTrailerId = youtubeTrailerId || "TSmJEZoVHTk";
        payload.pricePhysical = pricePhysical || "$69.99 USD / 69,99 €";
        payload.carouselImages = carouselImages.filter((url) => url.trim().length > 0);
        payload.characters = gameCharacters.filter((c) => c.name.trim().length > 0);
      } else if (category === "music") {
        payload.youtubeId = musicYoutubeId || "eVTXPUF4Oz4";
        payload.bandMembers = bandMembers.filter((m) => m.name.trim().length > 0);
      } else if (category === "theatre") {
        payload.imageUrl = theaterImage || payload.coverImage;
        payload.characters = theaterCharacters.filter((c) => c.name.trim().length > 0);
      } else if (category === "football") {
        payload.stadium = stadium || location || "Estadio Principal";
        payload.time = matchTime || "6:10 PM";
        payload.youtubeStreamId = youtubeStreamId;
        payload.homeTeam = homeTeam;
        payload.awayTeam = awayTeam;
      }

      const res = await fetch("/api/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Error al crear evento");

      window.location.href = data.event?.id ? `/events/${data.event.id}` : "/events";
    } catch (err: any) {
      setError(err.message || "Ocurrió un error");
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-4xl p-4 sm:p-6 lg:p-8 space-y-6">
      <div>
        <Link
          href="/admin/dashboard"
          className="text-xs text-blue-500 hover:underline font-semibold"
        >
          ← Volver al Panel Admin
        </Link>
        <h1 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white mt-2">
          Crear Nuevo Evento o Estreno
        </h1>
        <p className="text-xs text-gray-500 dark:text-gray-400">
          Formulario completo para administradores con soporte de carrusel, frases de personajes, directores técnicos y estadios.
        </p>
      </div>

      <div className="p-6 sm:p-8 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-xl">
        {error && (
          <div className="mb-4 p-3 text-xs bg-red-100 text-red-600 dark:bg-red-950 dark:text-red-400 rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* INFORMACIÓN GENERAL */}
          <div className="border-b border-gray-200 dark:border-gray-800 pb-5 space-y-4">
            <h2 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <span>📋</span> Información General
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                  Título del Evento
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                  placeholder="Ej. The Legend of Zelda / Boyacá Chicó vs Pasto"
                  className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                  Categoría
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white"
                >
                  {categoriesData.filter((c) => c.slug !== "all").map((cat) => (
                    <option key={cat.slug} value={cat.slug} className="dark:bg-gray-900">
                      {cat.icon || "📁"} {cat.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                  Fecha
                </label>
                <input
                  type="text"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                  placeholder="Ej. 25 de septiembre de 2026"
                  className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                  Lugar / Ciudad
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Ej. Tunja, Colombia / Nintendo Switch 2"
                  className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                  Precio de Boleta / Juego
                </label>
                <input
                  type="text"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="Ej. $59.99 USD / $25.000 COP"
                  className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                  URL Carátula / Imagen Principal
                </label>
                <input
                  type="url"
                  value={coverImage}
                  onChange={(e) => setCoverImage(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                Descripción
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                placeholder="Detalla de qué trata la obra, concierto, videojuego o partido..."
                className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white"
              />
            </div>

            <div className="flex items-center gap-3 p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900">
              <input
                type="checkbox"
                id="create-upcoming"
                checked={upcoming}
                onChange={(e) => setUpcoming(e.target.checked)}
                className="w-4 h-4 text-amber-600 rounded cursor-pointer"
              />
              <label htmlFor="create-upcoming" className="text-xs font-bold text-amber-900 dark:text-amber-300 cursor-pointer">
                🔥 Es un "Próximo Estreno" (Se mostrará en la sección de próximos estrenos 2026)
              </label>
            </div>
          </div>

          {/* CAMPOS ESPECÍFICOS DE VIDEOJUEGOS */}
          {category === "games" && (
            <div className="p-5 bg-amber-50/50 dark:bg-amber-950/20 border-2 border-amber-500/30 rounded-2xl space-y-6">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <span>🎮</span> Configuración Específica de Videojuego
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                    ID Trailer de YouTube
                  </label>
                  <input
                    type="text"
                    value={youtubeTrailerId}
                    onChange={(e) => setYoutubeTrailerId(e.target.value)}
                    placeholder="TSmJEZoVHTk"
                    className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                    Precio Físico (Cartucho)
                  </label>
                  <input
                    type="text"
                    value={pricePhysical}
                    onChange={(e) => setPricePhysical(e.target.value)}
                    placeholder="$69.99 USD / 69,99 €"
                    className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm"
                  />
                </div>
              </div>

              {/* CARRUSEL DE 5 IMÁGENES */}
              <div className="space-y-3">
                <label className="block text-xs font-black uppercase text-amber-700 dark:text-amber-300">
                  🖼️ Carrusel de 5 Imágenes del Juego (Independientes de la Portada Principal):
                </label>
                <div className="grid grid-cols-1 gap-2.5">
                  {carouselImages.map((imgUrl, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <span className="text-xs font-bold w-6 text-gray-400">#{idx + 1}</span>
                      <input
                        type="url"
                        value={imgUrl}
                        onChange={(e) => handleCarouselChange(idx, e.target.value)}
                        placeholder={`URL de la captura ${idx + 1}`}
                        className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg text-xs bg-white dark:bg-gray-900"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* PERSONAJES CON FRASE */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-black uppercase text-amber-700 dark:text-amber-300">
                    🗡️ Personajes Principales (Foto circular y Frase de Voz interactiva):
                  </label>
                  <button
                    type="button"
                    onClick={addGameCharacter}
                    className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold rounded-lg cursor-pointer"
                  >
                    + Añadir Personaje
                  </button>
                </div>

                <div className="space-y-3">
                  {gameCharacters.map((char, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-amber-600">Personaje #{idx + 1}</span>
                        {gameCharacters.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeGameCharacter(idx)}
                            className="text-[11px] text-red-500 hover:underline"
                          >
                            Eliminar
                          </button>
                        )}
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <input
                          type="text"
                          placeholder="Nombre del personaje (ej. Link)"
                          value={char.name}
                          onChange={(e) => handleGameCharacterChange(idx, "name", e.target.value)}
                          className="w-full px-2.5 py-1.5 border rounded-lg text-xs"
                        />
                        <input
                          type="url"
                          placeholder="URL foto circular"
                          value={char.imageUrl}
                          onChange={(e) => handleGameCharacterChange(idx, "imageUrl", e.target.value)}
                          className="w-full px-2.5 py-1.5 border rounded-lg text-xs"
                        />
                        <input
                          type="text"
                          placeholder="Frase / Voz al click"
                          value={char.phrase}
                          onChange={(e) => handleGameCharacterChange(idx, "phrase", e.target.value)}
                          className="w-full px-2.5 py-1.5 border rounded-lg text-xs"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* CAMPOS ESPECÍFICOS DE MÚSICA */}
          {category === "music" && (
            <div className="p-5 bg-blue-50/50 dark:bg-blue-950/20 border-2 border-blue-500/30 rounded-2xl space-y-4">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <span>🎵</span> Configuración Específica de Música
              </h3>

              <div>
                <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                  ID Video de YouTube
                </label>
                <input
                  type="text"
                  value={musicYoutubeId}
                  onChange={(e) => setMusicYoutubeId(e.target.value)}
                  placeholder="eVTXPUF4Oz4"
                  className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm"
                />
              </div>

              {/* INTEGRANTES */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-black uppercase text-blue-700 dark:text-blue-300">
                    🎸 Integrantes de la Banda / Músicos:
                  </label>
                  <button
                    type="button"
                    onClick={addBandMember}
                    className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg cursor-pointer"
                  >
                    + Añadir Músico
                  </button>
                </div>

                <div className="space-y-2.5">
                  {bandMembers.map((member, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl flex flex-col sm:flex-row items-center gap-2"
                    >
                      <input
                        type="text"
                        placeholder="Nombre (ej. Chester Bennington)"
                        value={member.name}
                        onChange={(e) => handleBandMemberChange(idx, "name", e.target.value)}
                        className="flex-1 px-2.5 py-1.5 border rounded-lg text-xs"
                      />
                      <input
                        type="text"
                        placeholder="Rol (ej. Voz Principal, Batería)"
                        value={member.role}
                        onChange={(e) => handleBandMemberChange(idx, "role", e.target.value)}
                        className="flex-1 px-2.5 py-1.5 border rounded-lg text-xs"
                      />
                      <input
                        type="url"
                        placeholder="URL Foto"
                        value={member.imageUrl}
                        onChange={(e) => handleBandMemberChange(idx, "imageUrl", e.target.value)}
                        className="flex-1 px-2.5 py-1.5 border rounded-lg text-xs"
                      />
                      {bandMembers.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeBandMember(idx)}
                          className="text-xs text-red-500 px-2 py-1"
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* CAMPOS ESPECÍFICOS DE TEATRO */}
          {category === "theatre" && (
            <div className="p-5 bg-purple-50/50 dark:bg-purple-950/20 border-2 border-purple-500/30 rounded-2xl space-y-4">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <span>🎭</span> Configuración Específica de Teatro
              </h3>

              <div>
                <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                  URL Cartel de la Obra (Afiche vertical)
                </label>
                <input
                  type="url"
                  value={theaterImage}
                  onChange={(e) => setTheaterImage(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm"
                />
              </div>

              {/* PERSONAJES PRINCIPALES Y ACTORES */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-black uppercase text-purple-700 dark:text-purple-300">
                    👥 Personajes Principales y Actores que los Representan:
                  </label>
                  <button
                    type="button"
                    onClick={addTheaterCharacter}
                    className="px-2.5 py-1 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-lg cursor-pointer"
                  >
                    + Añadir Personaje
                  </button>
                </div>

                <div className="space-y-2.5">
                  {theaterCharacters.map((char, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl flex flex-col sm:flex-row items-center gap-2"
                    >
                      <input
                        type="text"
                        placeholder="Personaje (ej. Romeo Montesco)"
                        value={char.name}
                        onChange={(e) => handleTheaterCharacterChange(idx, "name", e.target.value)}
                        className="flex-1 px-2.5 py-1.5 border rounded-lg text-xs"
                      />
                      <input
                        type="text"
                        placeholder="Actor / Actriz (ej. Carlos Rivera)"
                        value={char.actor}
                        onChange={(e) => handleTheaterCharacterChange(idx, "actor", e.target.value)}
                        className="flex-1 px-2.5 py-1.5 border rounded-lg text-xs"
                      />
                      <input
                        type="url"
                        placeholder="URL Foto del actor"
                        value={char.imageUrl}
                        onChange={(e) => handleTheaterCharacterChange(idx, "imageUrl", e.target.value)}
                        className="flex-1 px-2.5 py-1.5 border rounded-lg text-xs"
                      />
                      {theaterCharacters.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeTheaterCharacter(idx)}
                          className="text-xs text-red-500 px-2 py-1"
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* CAMPOS ESPECÍFICOS DE FÚTBOL */}
          {category === "football" && (
            <div className="p-5 bg-emerald-50/50 dark:bg-emerald-950/20 border-2 border-emerald-500/30 rounded-2xl space-y-6">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <span>⚽</span> Configuración Específica del Partido de Fútbol
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                    Estadio donde Juegan
                  </label>
                  <input
                    type="text"
                    value={stadium}
                    onChange={(e) => setStadium(e.target.value)}
                    placeholder="Estadio La Independencia (Tunja)"
                    className="w-full px-3 py-2 border rounded-xl text-xs bg-white dark:bg-gray-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                    Hora del Encuentro
                  </label>
                  <input
                    type="text"
                    value={matchTime}
                    onChange={(e) => setMatchTime(e.target.value)}
                    placeholder="6:10 PM / 8:00 PM"
                    className="w-full px-3 py-2 border rounded-xl text-xs bg-white dark:bg-gray-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                    YouTube Stream Directo
                  </label>
                  <input
                    type="text"
                    value={youtubeStreamId}
                    onChange={(e) => setYoutubeStreamId(e.target.value)}
                    placeholder="live_stream_id"
                    className="w-full px-3 py-2 border rounded-xl text-xs bg-white dark:bg-gray-900"
                  />
                </div>
              </div>

              {/* EQUIPO LOCAL */}
              <div className="p-4 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl space-y-3">
                <span className="text-xs font-black uppercase text-blue-600 dark:text-blue-400">
                  🛡️ Equipo Local (Totalmente a la Izquierda)
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Nombre del Equipo Local (ej. Boyacá Chicó FC)"
                    value={homeTeam.name}
                    onChange={(e) => setHomeTeam({ ...homeTeam, name: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                  <input
                    type="url"
                    placeholder="URL Escudo / Logo Local"
                    value={homeTeam.logoUrl}
                    onChange={(e) => setHomeTeam({ ...homeTeam, logoUrl: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Nombre del Director Técnico"
                    value={homeTeam.coach}
                    onChange={(e) => setHomeTeam({ ...homeTeam, coach: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                  <input
                    type="url"
                    placeholder="URL Foto del Director Técnico"
                    value={homeTeam.coachImageUrl}
                    onChange={(e) => setHomeTeam({ ...homeTeam, coachImageUrl: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Nombre del Capitán de Campo"
                    value={homeTeam.captain}
                    onChange={(e) => setHomeTeam({ ...homeTeam, captain: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                  <input
                    type="url"
                    placeholder="URL Foto del Capitán"
                    value={homeTeam.captainImageUrl}
                    onChange={(e) => setHomeTeam({ ...homeTeam, captainImageUrl: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                </div>
              </div>

              {/* EQUIPO VISITANTE */}
              <div className="p-4 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl space-y-3">
                <span className="text-xs font-black uppercase text-amber-600 dark:text-amber-400">
                  ⚔️ Equipo Visitante (Totalmente a la Derecha)
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Nombre del Equipo Visitante (ej. Deportivo Pasto)"
                    value={awayTeam.name}
                    onChange={(e) => setAwayTeam({ ...awayTeam, name: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                  <input
                    type="url"
                    placeholder="URL Escudo / Logo Visitante"
                    value={awayTeam.logoUrl}
                    onChange={(e) => setAwayTeam({ ...awayTeam, logoUrl: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Nombre del Director Técnico"
                    value={awayTeam.coach}
                    onChange={(e) => setAwayTeam({ ...awayTeam, coach: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                  <input
                    type="url"
                    placeholder="URL Foto del Director Técnico"
                    value={awayTeam.coachImageUrl}
                    onChange={(e) => setAwayTeam({ ...awayTeam, coachImageUrl: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Nombre del Capitán de Campo"
                    value={awayTeam.captain}
                    onChange={(e) => setAwayTeam({ ...awayTeam, captain: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                  <input
                    type="url"
                    placeholder="URL Foto del Capitán"
                    value={awayTeam.captainImageUrl}
                    onChange={(e) => setAwayTeam({ ...awayTeam, captainImageUrl: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                </div>
              </div>
            </div>
          )}

          <div className="pt-4 flex items-center justify-end gap-3 border-t border-gray-100 dark:border-gray-800">
            <Link
              href="/admin/dashboard"
              className="px-4 py-2.5 border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 text-sm font-semibold rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            >
              Cancelar
            </Link>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm rounded-xl shadow-md transition-colors cursor-pointer"
            >
              {loading ? "Publicando..." : "Publicar Evento"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
