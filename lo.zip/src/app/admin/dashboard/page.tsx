import Link from "next/link";
import { cookies } from "next/headers";
import { getEvents } from "@/data/events";
import { getCategories } from "@/data/categories";

export const dynamic = "force-dynamic";

export default async function AdminDashboardPage() {
  const cookieStore = await cookies();
  const userName = cookieStore.get("user_name")?.value || "Administrador";

  const allEvents = getEvents();
  const allCategories = getCategories();
  const totalEvents = allEvents.length;
  const totalUpcoming = allEvents.filter((e) => e.upcoming).length;
  const totalCategories = allCategories.length;

  return (
    <div className="mx-auto max-w-6xl p-4 sm:p-6 lg:p-8 text-gray-900 dark:text-white space-y-8">
      {/* Encabezado */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-6 border-gray-200 dark:border-gray-800">
        <div>
          <span className="text-xs font-black uppercase px-3 py-1 bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300 rounded-full">
            👑 Panel de Control Oficial
          </span>
          <h1 className="text-3xl font-black mt-2 tracking-tight">
            Dashboard de Administración
          </h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Bienvenido, <strong>{userName}</strong>. Tienes permisos para crear, editar y eliminar eventos y categorías.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/admin/events/create"
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
          >
            <span>➕</span>
            <span>Nuevo Evento</span>
          </Link>
          <Link
            href="/admin/categories/create"
            className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
          >
            <span>📁</span>
            <span>Nueva Categoría</span>
          </Link>
        </div>
      </div>

      {/* Métricas del Sistema */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="p-6 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-sm">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500">
            Total Eventos en Catálogo
          </h3>
          <p className="text-3xl font-black mt-2 text-blue-600 dark:text-blue-400">
            {totalEvents}
          </p>
          <span className="text-[11px] text-gray-400">Música, Juegos, Teatro y Fútbol</span>
        </div>

        <div className="p-6 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-sm">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500">
            Próximos Estrenos 2026
          </h3>
          <p className="text-3xl font-black mt-2 text-amber-500">
            {totalUpcoming}
          </p>
          <span className="text-[11px] text-gray-400">Lanzamientos y preventas activas</span>
        </div>

        <div className="p-6 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-sm">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500">
            Categorías Gestionadas
          </h3>
          <p className="text-3xl font-black mt-2 text-purple-600 dark:text-purple-400">
            {totalCategories}
          </p>
          <span className="text-[11px] text-gray-400">Permisos CRUD completos</span>
        </div>
      </div>

      {/* ── GESTIÓN DE EVENTOS (Listado con opciones de editar y eliminar) ── */}
      <div className="p-6 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold">Gestión de Eventos y Estrenos</h2>
          <Link
            href="/admin/events/create"
            className="text-xs font-bold text-blue-600 hover:underline"
          >
            + Añadir Evento
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-gray-200 dark:border-gray-800 text-xs uppercase text-gray-400">
              <tr>
                <th className="py-3 px-4">Título</th>
                <th className="py-3 px-4">Categoría</th>
                <th className="py-3 px-4">Fecha</th>
                <th className="py-3 px-4">Precio</th>
                <th className="py-3 px-4 text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {allEvents.map((ev) => (
                <tr key={ev.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                  <td className="py-3 px-4 font-bold text-gray-900 dark:text-white">
                    {ev.title}
                  </td>
                  <td className="py-3 px-4 capitalize">
                    <span className="text-xs px-2 py-0.5 rounded-full bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 font-semibold">
                      {ev.category}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-xs text-gray-500">{ev.date}</td>
                  <td className="py-3 px-4 text-xs font-semibold">
                    {"price" in ev ? ev.price : "N/A"}
                  </td>
                  <td className="py-3 px-4 text-right space-x-2">
                    <Link
                      href={`/events/${ev.id}`}
                      className="text-xs text-blue-500 hover:underline font-semibold"
                    >
                      Ver
                    </Link>
                    <Link
                      href={`/admin/events/${ev.id}/edit`}
                      className="text-xs text-amber-500 hover:underline font-semibold"
                    >
                      Editar
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ── GESTIÓN DE CATEGORÍAS ── */}
      <div className="p-6 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold">Gestión de Categorías</h2>
          <Link
            href="/admin/categories/create"
            className="text-xs font-bold text-purple-600 hover:underline"
          >
            + Añadir Categoría
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {allCategories.filter((c) => c.slug !== "all").map((cat) => (
            <div
              key={cat.id}
              className="p-4 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-950/40 flex items-center justify-between"
            >
              <div className="flex items-center gap-2.5">
                <span className="text-2xl">{cat.icon || "📁"}</span>
                <div>
                  <h4 className="font-bold text-sm">{cat.name}</h4>
                  <p className="text-[11px] text-gray-400">/{cat.slug}</p>
                </div>
              </div>

              <Link
                href={`/admin/categories/${cat.id}/edit`}
                className="text-xs font-bold text-purple-600 dark:text-purple-400 hover:underline"
              >
                Editar
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}