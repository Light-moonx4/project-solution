import { NextResponse } from "next/server";
import { categoriesData, updateCategory, deleteCategory } from "@/data/categories";
import { saveCategoriesToDisk } from "@/lib/server-storage";
import { cookies } from "next/headers";
import { revalidatePath } from "next/cache";

interface RouteParams {
  params: Promise<{ id: string }>;
}

export async function GET(request: Request, { params }: RouteParams) {
  const { id } = await params;
  const category = categoriesData.find((c) => c.id === id || c.slug === id);
  if (!category) {
    return NextResponse.json({ message: "Categoría no encontrada" }, { status: 404 });
  }
  return NextResponse.json(category);
}

export async function PUT(request: Request, { params }: RouteParams) {
  const cookieStore = await cookies();
  const token = cookieStore.get("token")?.value;
  const role = cookieStore.get("role")?.value;

  if (!token && role !== "admin") {
    return NextResponse.json({ message: "No autorizado" }, { status: 403 });
  }

  const { id } = await params;
  try {
    const body = await request.json();
    const success = updateCategory(id, body);
    if (!success) {
      return NextResponse.json({ message: "Categoría no encontrada" }, { status: 404 });
    }

    saveCategoriesToDisk();

    try {
      revalidatePath("/categories");
      revalidatePath(`/categories/${id}`);
      revalidatePath("/admin/dashboard");
      revalidatePath("/");
    } catch (e) {}

    return NextResponse.json({ message: "Categoría actualizada correctamente" });
  } catch (error) {
    return NextResponse.json({ message: "Error al actualizar la categoría" }, { status: 500 });
  }
}

export async function DELETE(request: Request, { params }: RouteParams) {
  const cookieStore = await cookies();
  const token = cookieStore.get("token")?.value;
  const role = cookieStore.get("role")?.value;

  if (!token && role !== "admin") {
    return NextResponse.json({ message: "No autorizado" }, { status: 403 });
  }

  const { id } = await params;
  const success = deleteCategory(id);
  if (!success) {
    return NextResponse.json({ message: "Categoría no encontrada" }, { status: 404 });
  }

  saveCategoriesToDisk();

  try {
    revalidatePath("/categories");
    revalidatePath("/admin/dashboard");
    revalidatePath("/");
  } catch (e) {}

  return NextResponse.json({ message: "Categoría eliminada correctamente" });
}
