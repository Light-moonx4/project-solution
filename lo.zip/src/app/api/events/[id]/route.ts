import { NextResponse } from "next/server";
import { getEventById, updateEvent, deleteEvent } from "@/data/events";
import { saveEventsToDisk } from "@/lib/server-storage";
import { cookies } from "next/headers";
import { revalidatePath } from "next/cache";

interface RouteParams {
  params: Promise<{ id: string }>;
}

export async function GET(request: Request, { params }: RouteParams) {
  const { id } = await params;
  const event = getEventById(id);
  if (!event) {
    return NextResponse.json({ message: "Evento no encontrado" }, { status: 404 });
  }
  return NextResponse.json(event);
}

export async function PUT(request: Request, { params }: RouteParams) {
  const cookieStore = await cookies();
  const token = cookieStore.get("token")?.value;
  const role = cookieStore.get("role")?.value;

  // Permitir la edición si está logueado como admin o tiene token de sesión
  if (!token && role !== "admin") {
    return NextResponse.json({ message: "No autorizado. Inicia sesión como administrador." }, { status: 403 });
  }

  const { id } = await params;
  try {
    const body = await request.json();
    const success = updateEvent(id, body);
    if (!success) {
      return NextResponse.json({ message: "Evento no encontrado" }, { status: 404 });
    }

    // Guardar cambio en disco físico
    saveEventsToDisk();

    // Revalidar inmediatamente las rutas de Next.js
    try {
      revalidatePath("/");
      revalidatePath("/events");
      revalidatePath(`/events/${id}`);
      revalidatePath("/admin/dashboard");
    } catch (e) {}

    const updatedEvent = getEventById(id);
    return NextResponse.json({
      message: "Evento actualizado correctamente",
      event: updatedEvent,
    });
  } catch (error) {
    return NextResponse.json({ message: "Error al actualizar evento" }, { status: 500 });
  }
}

export async function DELETE(request: Request, { params }: RouteParams) {
  const cookieStore = await cookies();
  const token = cookieStore.get("token")?.value;
  const role = cookieStore.get("role")?.value;

  if (!token && role !== "admin") {
    return NextResponse.json({ message: "No autorizado" }, { status: 403 });
  }

  const { id } = await params;
  const success = deleteEvent(id);
  if (!success) {
    return NextResponse.json({ message: "Evento no encontrado" }, { status: 404 });
  }

  saveEventsToDisk();

  try {
    revalidatePath("/");
    revalidatePath("/events");
    revalidatePath("/admin/dashboard");
  } catch (e) {}

  return NextResponse.json({ message: "Evento eliminado correctamente" });
}
