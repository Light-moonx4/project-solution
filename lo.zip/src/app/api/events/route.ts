import { NextResponse } from "next/server";
import { getEvents, addEvent } from "@/data/events";
import { saveEventsToDisk } from "@/lib/server-storage";
import { cookies } from "next/headers";
import { revalidatePath } from "next/cache";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const category = searchParams.get("category");
  const upcoming = searchParams.get("upcoming");

  let result = getEvents();

  if (category && category !== "all") {
    result = result.filter((e) => e.category === category);
  }

  if (upcoming === "true") {
    result = result.filter((e) => e.upcoming === true);
  } else if (upcoming === "false") {
    result = result.filter((e) => !e.upcoming);
  }

  return NextResponse.json(result);
}

export async function POST(request: Request) {
  const cookieStore = await cookies();
  const token = cookieStore.get("token")?.value;
  const role = cookieStore.get("role")?.value;

  if (!token && role !== "admin") {
    return NextResponse.json({ message: "No autorizado. Solo administradores pueden crear eventos." }, { status: 403 });
  }

  try {
    const body = await request.json();
    const { title, category, date, description, price } = body;

    if (!title || !category || !date) {
      return NextResponse.json({ message: "Título, categoría y fecha son obligatorios" }, { status: 400 });
    }

    const generatedId = title
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "") + "-" + Date.now().toString().slice(-4);

    const newEvent = {
      ...body,
      id: body.id || generatedId,
      category,
      price: price || "Gratis",
    };

    addEvent(newEvent);
    saveEventsToDisk();

    try {
      revalidatePath("/");
      revalidatePath("/events");
      revalidatePath("/admin/dashboard");
    } catch (e) {}

    return NextResponse.json({ message: "Evento creado exitosamente", event: newEvent }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ message: "Error al procesar la solicitud" }, { status: 500 });
  }
}
