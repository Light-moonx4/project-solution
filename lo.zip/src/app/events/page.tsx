import Link from "next/link";
import { cookies } from "next/headers";
import EventsAside from "@/components/events/EventsAside";
import { eventsData, getEventsByCategory } from "@/data/events";

interface EventsPageProps {
  searchParams: Promise<{ category?: string; filter?: string }>;
}

export const dynamic = "force-dynamic";

export default async function EventsPage({ searchParams }: EventsPageProps) {
  const { category, filter } = await searchParams;

  const cookieStore = await cookies();
  const token = cookieStore.get("token")?.value;
  const role = cookieStore.get("role")?.value || "user";
  const isAdmin = token && role === "admin";
  const isAuthenticated = Boolean(token);

  let displayList = getEventsByCategory(category || "all");

  if (filter === "upcoming") {
    displayList = displayList.filter((e) => e.upcoming);
  } else if (filter === "current") {
    displayList = displayList.filter((e) => !e.upcoming);
  }

  const getEventLink = (id: string) => {
    if (isAuthenticated) {
      return `/events/${id}`;
    }
    return `/login?redirect=/events/${id}`;
  };

  return (
    <div className="mx-auto max-w-7xl p-4 sm:p-6 lg:p-8 flex flex-col md:flex-row gap-8">
      {/* Barra lateral de filtros */}
      <EventsAside activeCategory={category ?? "all"} />

      {/* Contenido principal */}
      <div className="flex-1">
        {/* Encabezado con título y botón de Crear Evento para Admin */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-gray-200 dark:border-gray-800">
          <div>
            <h1 className="text-3xl font-black text-gray-900 dark:text-white">
              Catálogo de Eventos
            </h1>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              Explora conciertos, lanzamientos de videojuegos, obras de teatro y partidos.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* ── BOTÓN VISIBLE SOLO PARA ADMIN ── */}
            {isAdmin && (
              <Link
                href="/admin/events/create"
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold transition-all shadow-md hover:shadow-lg flex items-center gap-1.5"
              >
                <span>➕</span>
                <span>Crear Evento</span>
              </Link>
            )}
          </div>
        </div>

        {/* Pestañas de filtrado rápido */}
        <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2">
          <Link
            href={category ? `/events?category=${category}` : "/events"}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
              !filter
                ? "bg-blue-600 text-white"
                : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200"
            }`}
          >
            Todos ({displayList.length})
          </Link>
          <Link
            href={category ? `/events?category=${category}&filter=upcoming` : "/events?filter=upcoming"}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
              filter === "upcoming"
                ? "bg-amber-500 text-black"
                : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200"
            }`}
          >
            🔥 Próximos Estrenos
          </Link>
          <Link
            href={category ? `/events?category=${category}&filter=current` : "/events?filter=current"}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
              filter === "current"
                ? "bg-emerald-600 text-white"
                : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200"
            }`}
          >
            En Cartelera / En Vivo
          </Link>
        </div>

        {/* Lista de eventos */}
        {displayList.length === 0 ? (
          <div className="p-12 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl text-center">
            <span className="text-4xl">📂</span>
            <p className="text-gray-600 dark:text-gray-400 mt-3 font-semibold">
              No hay eventos registrados para este filtro.
            </p>
            <div className="mt-4">
              <Link href="/events" className="text-blue-500 hover:underline text-sm font-bold">
                &larr; Ver todos los eventos disponibles
              </Link>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayList.map((event) => {
              const targetUrl = getEventLink(event.id);
              const locationStr = "location" in event && event.location ? event.location : undefined;

              return (
                <div
                  key={event.id}
                  className="flex flex-col justify-between rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden bg-white dark:bg-gray-900 shadow-sm hover:shadow-xl transition-all duration-300 hover:border-blue-500 group"
                >
                  {/* Portada */}
                  <div className="relative aspect-video bg-gray-950 overflow-hidden">
                    <img
                      src={event.coverImage || "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800"}
                      alt={event.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-2.5 left-2.5 flex gap-1.5">
                      <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-blue-600 text-white shadow-xs">
                        {event.category}
                      </span>
                      {event.upcoming && (
                        <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-500 text-black shadow-xs">
                          Próximo
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        📅 {event.date}
                      </p>
                      <h2 className="text-lg font-bold text-gray-900 dark:text-white mt-1 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors line-clamp-1">
                        {event.title}
                      </h2>
                      <p className="text-xs text-gray-600 dark:text-gray-400 mt-2 line-clamp-2 leading-relaxed">
                        {event.description}
                      </p>
                      {locationStr && (
                        <div className="mt-3 text-[11px] text-gray-500 dark:text-gray-400 flex items-center gap-1 line-clamp-1">
                          📍 {locationStr}
                        </div>
                      )}
                    </div>

                    <div className="mt-5 pt-4 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between">
                      {"price" in event && event.price && (
                        <span className="text-xs font-black text-gray-900 dark:text-white">
                          {event.price}
                        </span>
                      )}

                      <Link
                        href={targetUrl}
                        className="rounded-xl bg-blue-600 px-3.5 py-1.5 text-xs font-bold text-white hover:bg-blue-500 transition-colors shadow-xs"
                      >
                        {isAuthenticated ? "Ver Detalle →" : "🔒 Ingresar"}
                      </Link>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
