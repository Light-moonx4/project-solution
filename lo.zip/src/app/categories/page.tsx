import Link from "next/link";
import { cookies } from "next/headers";
import CategoriesAside from "@/components/categories/CategoriesAside";
import CreateCategoriesButton from "@/components/ui/CreateCategoriesButton";
import { getCategories } from "@/data/categories";
import { getEvents } from "@/data/events";

export const dynamic = "force-dynamic";

export default async function CategoriesPage() {
  const cookieStore = await cookies();
  const token = cookieStore.get("token")?.value;
  const role = cookieStore.get("role")?.value || "user";
  const isAdmin = token && role === "admin";

  const allCategories = getCategories();
  const allEvents = getEvents();
  const publicCategories = allCategories.filter((c) => c.slug !== "all");

  return (
    <div className="mx-auto max-w-6xl p-4 sm:p-6 lg:p-8 flex flex-col md:flex-row gap-8">
      {/* Barra lateral */}
      <CategoriesAside />

      {/* Contenido principal */}
      <main className="flex-1 space-y-6">
        <div className="p-6 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="text-3xl font-black text-gray-900 dark:text-white">
                Categorías de Eventos
              </h1>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                Explora los catálogos organizados por temática artística, deportiva y entretenimiento.
              </p>
            </div>

            {/* BOTÓN VISIBLE SOLO CUANDO ES ADMIN (Requerimiento explícito del usuario) */}
            {isAdmin && <CreateCategoriesButton isAdmin={isAdmin} />}
          </div>
        </div>

        {/* Tarjetas de cada categoría */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {publicCategories.map((cat) => {
            const count = allEvents.filter((e) => e.category === cat.slug).length;

            return (
              <div
                key={cat.id}
                className="p-5 rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-3xl">{cat.icon || "📁"}</span>
                    <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400">
                      {count} evento(s)
                    </span>
                  </div>
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                    {cat.name}
                  </h2>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    {cat.description || "Eventos y presentaciones exclusivas."}
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between">
                  <Link
                    href={`/categories/${cat.slug}`}
                    className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    Ver detalles &rarr;
                  </Link>

                  <Link
                    href={`/events?category=${cat.slug}`}
                    className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 transition-colors"
                  >
                    Ver en Eventos
                  </Link>
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex gap-4 pt-4">
          <Link href="/" className="text-blue-500 hover:underline text-sm font-semibold">
            &larr; Volver al Inicio
          </Link>
          <Link href="/events" className="text-blue-500 hover:underline text-sm font-semibold">
            Explorar todos los Eventos &rarr;
          </Link>
        </div>
      </main>
    </div>
  );
}