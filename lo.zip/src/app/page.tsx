import Link from "next/link";
import { cookies } from "next/headers";
import { getEvents, getEventsByCategory } from "@/data/events";
import { getCategories } from "@/data/categories";
import UpcomingEventsSection from "@/components/events/UpcomingEventsSection";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const cookieStore = await cookies();
  const token = cookieStore.get("token")?.value;
  const role = cookieStore.get("role")?.value || "user";
  const userName = cookieStore.get("user_name")?.value;
  const isAuthenticated = Boolean(token);
  const isAdmin = isAuthenticated && role === "admin";

  const getEventLink = (id: string) => {
    if (isAuthenticated) {
      return `/events/${id}`;
    }
    return `/login?redirect=/events/${id}`;
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white transition-colors pb-16">
      {/* ── HERO BANNER ── */}
      <section className="relative overflow-hidden bg-gradient-to-b from-blue-600/10 via-purple-600/5 to-transparent border-b border-gray-200 dark:border-gray-800 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 text-xs font-bold mb-4 shadow-xs">
            <span>✨</span> Plataforma Oficial de Eventos y Estrenos 2026
          </div>

          <h1 className="text-4xl sm:text-6xl font-black tracking-tight text-gray-900 dark:text-white max-w-4xl mx-auto leading-tight">
            Descubre, Vive y Reserva los Mejores <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">Eventos Globales</span>
          </h1>

          <p className="mt-4 text-base sm:text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Música en vivo, estrenos de videojuegos, obras de teatro y fútbol en directo. Inicia sesión para disfrutar de transmisiones y contenido interactivo exclusivo.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <Link
              href="#proximos"
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-extrabold text-sm shadow-lg hover:shadow-xl transition-all flex items-center gap-2"
            >
              <span>🔥</span>
              <span>Ver Próximos Estrenos 2026</span>
            </Link>

            <Link
              href="/events"
              className="px-6 py-3 rounded-xl bg-white dark:bg-gray-900 hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-900 dark:text-white font-bold text-sm border border-gray-200 dark:border-gray-700 shadow-sm transition-all"
            >
              Explorar Catálogo Completo &rarr;
            </Link>

            {!isAuthenticated && (
              <Link
                href="/login"
                className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-sm transition-all"
              >
                Iniciar Sesión
              </Link>
            )}
          </div>

          {/* Banner de estado de usuario */}
          <div className="mt-6">
            {isAuthenticated ? (
              <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-xs font-semibold">
                <span>🟢</span>
                <span>Sesión activa como: <strong>{userName || (isAdmin ? "Administrador" : "Usuario")}</strong> ({role})</span>
              </div>
            ) : (
              <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 text-xs font-semibold">
                <span>🔒</span>
                <span>Modo invitado: Inicia sesión para acceder al contenido multimedia y comprar boletos</span>
              </div>
            )}
          </div>
        </div>
      </section>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 space-y-16">
        {/* ── SECCIÓN 1: PRÓXIMOS EVENTOS, CONCIERTOS O ESTRENOS (Requerido por usuario) ── */}
        <UpcomingEventsSection events={getEvents()} isAuthenticated={isAuthenticated} />

        {/* ── SECCIÓN 2: EVENTOS EN CARTELERA Y EN VIVO POR CATEGORÍA ── */}
        <section className="space-y-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-gray-200 dark:border-gray-800 pb-4">
            <div>
              <span className="text-xs font-black uppercase tracking-widest text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950 px-3 py-1 rounded-full">
                🎯 Categorías Oficiales
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white mt-2">
                Cartelera Actual y Eventos en Vivo
              </h2>
              <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1">
                Explora el contenido de cada categoría con enlaces verificados sin errores.
              </p>
            </div>

            <Link
              href="/categories"
              className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
            >
              Ver todas las categorías &rarr;
            </Link>
          </div>

          <div className="space-y-10">
            {getCategories().filter((c) => c.slug !== "all").map((cat) => {
              const categoryEvents = getEventsByCategory(cat.slug);

              return (
                <div
                  key={cat.slug}
                  className="p-6 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-md transition-all hover:border-gray-300 dark:hover:border-gray-700"
                >
                  <div className="flex items-center justify-between gap-4 mb-4 pb-3 border-b border-gray-100 dark:border-gray-800">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{cat.icon || "📁"}</span>
                      <div>
                        <h3 className="text-xl font-black text-gray-900 dark:text-white">
                          {cat.name}
                        </h3>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          {cat.description}
                        </p>
                      </div>
                    </div>

                    <Link
                      href={`/events?category=${cat.slug}`}
                      className="text-xs font-bold px-3 py-1.5 rounded-lg bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 transition-colors"
                    >
                      Ver todos ({categoryEvents.length}) &rarr;
                    </Link>
                  </div>

                  {/* Listado de eventos de esta categoría */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {categoryEvents.map((item) => {
                      const linkHref = getEventLink(item.id);
                      return (
                        <Link
                          key={item.id}
                          href={linkHref}
                          className="group flex flex-col justify-between p-4 rounded-xl border border-gray-200 dark:border-gray-800 hover:border-blue-500 dark:hover:border-blue-500 bg-gray-50/50 dark:bg-gray-950/40 transition-all hover:shadow-md"
                        >
                          <div>
                            <div className="flex items-center justify-between gap-2 mb-1.5">
                              <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                                {item.upcoming ? "Próximo" : "En Cartelera"}
                              </span>
                              {"price" in item && item.price && (
                                <span className="text-xs font-black text-gray-900 dark:text-white">
                                  {item.price}
                                </span>
                              )}
                            </div>

                            <h4 className="font-bold text-sm text-gray-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors line-clamp-1">
                              {item.title}
                            </h4>

                            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 line-clamp-2">
                              {item.description}
                            </p>
                          </div>

                          <div className="mt-4 pt-3 border-t border-gray-200/60 dark:border-gray-800/80 flex items-center justify-between text-xs font-semibold">
                            <span className="text-[11px] text-gray-500">
                              {isAuthenticated ? "Acceder →" : "🔒 Iniciar Sesión"}
                            </span>
                            <span className="text-blue-600 dark:text-blue-400 group-hover:translate-x-1 transition-transform">
                              &rarr;
                            </span>
                          </div>
                        </Link>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>
    </div>
  );
}