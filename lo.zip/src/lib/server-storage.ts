import fs from "fs";
import path from "path";
import { getEvents, type EventItem } from "@/data/events";
import { getCategories, type CategoryItem } from "@/data/categories";

const EVENTS_JSON_PATH = path.join(process.cwd(), "src/data/events.json");
const CATEGORIES_JSON_PATH = path.join(process.cwd(), "src/data/categories.json");

export function saveEventsToDisk(): void {
  try {
    const data = getEvents();
    fs.writeFileSync(EVENTS_JSON_PATH, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving events to disk:", err);
  }
}

export function saveCategoriesToDisk(): void {
  try {
    const data = getCategories();
    fs.writeFileSync(CATEGORIES_JSON_PATH, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving categories to disk:", err);
  }
}
