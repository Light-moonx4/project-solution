import Link from "next/link";

interface Props {
  isAdmin?: boolean;
}

export default function CreateCategoriesButton({ isAdmin = true }: Props) {
  if (!isAdmin) return null;

  return (
    <Link
      href="/admin/categories/create"
      className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold transition-all text-xs shadow-sm hover:shadow-md cursor-pointer"
    >
      <span>➕</span>
      <span>Crear Categoría</span>
    </Link>
  );
}