"use client";

import { useState } from "react";
import type { MusicEventItem } from "@/data/events";

interface Props {
  event: MusicEventItem;
}

export default function MusicDetail({ event }: Props) {
  const [ticketBought, setTicketBought] = useState(false);

  return (
    <div className="space-y-8 animate-fade-in">
      {/* ── Encabezado Principal ── */}
      <div className="p-6 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-md">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950 px-3 py-1 rounded-full">
            🎵 Conciertos y Música en Vivo
          </span>
          {event.upcoming && (
            <span className="bg-amber-500 text-black text-xs font-black uppercase px-3 py-1 rounded-full shadow-xs">
              Próximo Estreno / Concierto
            </span>
          )}
        </div>

        <h1 className="text-2xl sm:text-4xl font-black text-gray-900 dark:text-white tracking-tight">
          {event.title}
        </h1>

        <div className="flex flex-wrap items-center gap-4 mt-3 text-sm text-gray-600 dark:text-gray-400">
          <span>📅 {event.date}</span>
          <span>•</span>
          <span>📍 {event.location}</span>
        </div>

        <p className="mt-4 text-gray-700 dark:text-gray-300 leading-relaxed text-sm sm:text-base">
          {event.description}
        </p>

        {/* Botón de compra / precio si existe */}
        {event.price && (
          <div className="mt-6 p-4 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <span className="text-xs uppercase font-bold text-gray-500 dark:text-gray-400">
                Precio de Boletos (Estados Unidos / General):
              </span>
              <p className="text-2xl font-black text-blue-700 dark:text-blue-300">
                {event.price}
              </p>
            </div>

            {ticketBought ? (
              <div className="px-5 py-2.5 bg-green-100 dark:bg-green-950 text-green-800 dark:text-green-300 rounded-xl text-xs font-bold border border-green-300">
                ✅ ¡Boleto adquirido para {event.title}! Revisa tu correo con el voucher.
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setTicketBought(true)}
                className="w-full sm:w-auto px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm rounded-xl shadow-md transition-all cursor-pointer"
              >
                🎟️ Comprar Boleto ({event.price})
              </button>
            )}
          </div>
        )}
      </div>

      {/* ── Cuadro de Video de YouTube Embed ── */}
      {event.youtubeId && (
        <div className="p-6 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-md">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <span>🎥</span> Video Oficial y Presentación
          </h2>
          <div className="overflow-hidden rounded-xl bg-black aspect-video shadow-inner">
            <iframe
              className="w-full h-full"
              src={`https://www.youtube.com/embed/${event.youtubeId}`}
              title={event.title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        </div>
      )}

      {/* ── Miembros de la Banda o Intérpretes ── */}
      {event.bandMembers && event.bandMembers.length > 0 && (
        <div className="p-6 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-md">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <span>🎸</span> Integrantes y Músicos en Escenario
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {event.bandMembers.map((member, index) => (
              <div
                key={index}
                className="flex items-center space-x-4 p-4 bg-gray-50 dark:bg-gray-800/60 border border-gray-200 dark:border-gray-800 rounded-xl hover:border-blue-500 transition-colors"
              >
                <img
                  src={member.imageUrl}
                  alt={member.name}
                  className="w-16 h-16 rounded-full object-cover border-2 border-blue-500 shadow-xs"
                />
                <div>
                  <h3 className="text-sm font-bold text-gray-900 dark:text-white">
                    {member.name}
                  </h3>
                  <p className="text-xs text-blue-600 dark:text-blue-400 font-medium">
                    {member.role}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

