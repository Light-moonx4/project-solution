"use client";

import { useState } from "react";
import type { TheaterEventItem } from "@/data/events";

interface Props {
  theater: TheaterEventItem;
}

export default function TheaterDetail({ theater }: Props) {
  const [reserved, setReserved] = useState(false);

  return (
    <div className="space-y-8 animate-fade-in">
      {/* ── Cartel Principal y Presentación de la Obra ── */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 p-6 sm:p-8 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-md items-center">
        {/* Imagen de la obra que se representa */}
        <div className="relative overflow-hidden rounded-xl shadow-xl aspect-[3/4] border border-gray-200 dark:border-gray-800 group">
          <img
            src={theater.imageUrl}
            alt={`Cartel de la obra ${theater.title}`}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute top-3 left-3">
            {theater.upcoming ? (
              <span className="bg-purple-600 text-white text-xs font-black uppercase px-3 py-1 rounded-full shadow-md">
                Próximo Estreno
              </span>
            ) : (
              <span className="bg-emerald-600 text-white text-xs font-black uppercase px-3 py-1 rounded-full shadow-md">
                En Cartelera
              </span>
            )}
          </div>
        </div>

        {/* Nombre, Teatro y Descripción */}
        <div className="md:col-span-2 space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400">
            <span>🎭 Artes Escénicas</span>
            <span>•</span>
            <span>{theater.date}</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-black text-gray-900 dark:text-white tracking-tight">
            {theater.title}
          </h1>

          <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
            <span>📍 Lugar:</span>
            <strong className="text-gray-900 dark:text-white">{theater.location}</strong>
          </div>

          <div className="p-4 rounded-xl bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-800 text-gray-700 dark:text-gray-300 leading-relaxed text-sm">
            <h3 className="font-bold text-xs uppercase text-gray-400 mb-1">Sinopsis de la Obra:</h3>
            <p>{theater.description}</p>
          </div>

          {/* Tarjeta de precio y reserva */}
          <div className="p-4 rounded-xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800/60 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <span className="text-xs uppercase font-bold text-gray-500 dark:text-gray-400">
                Precio de Entrada / Boleta
              </span>
              <p className="text-2xl font-black text-purple-700 dark:text-purple-300">
                {theater.price}
              </p>
            </div>

            {reserved ? (
              <div className="px-4 py-2 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 rounded-lg text-xs font-bold border border-emerald-300">
                🎉 ¡Boleto Reservado con éxito!
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setReserved(true)}
                className="w-full sm:w-auto px-6 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-sm rounded-lg shadow-md transition-all cursor-pointer"
              >
                {theater.upcoming ? "🎟️ Reservar Boleta" : "🎟️ Comprar Boleta"} ({theater.price})
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ── Personajes Principales que se Representarán ── */}
      <div className="p-6 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-md">
        <div className="mb-6">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <span>👥</span> Personajes Principales y Elenco
          </h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
            Los actores y actrices que dan vida a los personajes de esta representación:
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {theater.characters.map((char, idx) => (
            <div
              key={idx}
              className="flex items-center gap-4 p-4 rounded-xl bg-gray-50 dark:bg-gray-800/60 border border-gray-200 dark:border-gray-800 hover:border-purple-500 transition-all shadow-xs"
            >
              <img
                src={char.imageUrl}
                alt={char.name}
                className="w-16 h-16 rounded-full object-cover border-2 border-purple-500 shadow-sm"
              />
              <div>
                <h3 className="font-black text-sm text-gray-900 dark:text-white">
                  {char.name}
                </h3>
                <p className="text-xs text-purple-600 dark:text-purple-400 font-semibold mt-0.5">
                  Interpretado por:
                </p>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  {char.actor}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

