"use client";

import { useState } from "react";
import type { FootballEventItem } from "@/data/events";

interface Props {
  match: FootballEventItem;
}

export default function FootballDetail({ match }: Props) {
  const [ticketBought, setTicketBought] = useState(false);
  const [ticketType, setTicketType] = useState<"general" | "vip">("general");

  return (
    <div className="space-y-8 animate-fade-in">
      {/* ── Marcador / Enfrentamiento Visual (Izquierda vs Derecha) ── */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-gray-900 via-blue-950 to-gray-900 text-white p-6 sm:p-8 border border-blue-900/50 shadow-2xl">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-4 mb-6">
          <div className="flex items-center gap-2">
            {match.isLive ? (
              <span className="flex items-center gap-1.5 bg-red-600 text-white text-xs font-black uppercase px-3 py-1 rounded-full animate-pulse shadow-md">
                <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                EN VIVO HOY
              </span>
            ) : (
              <span className="bg-blue-600/80 text-white text-xs font-bold uppercase px-3 py-1 rounded-full">
                Próximo Encuentro
              </span>
            )}
            <span className="text-xs text-gray-300 font-semibold">{match.date} • {match.time}</span>
          </div>

          <div className="text-xs bg-white/10 px-3 py-1 rounded-lg backdrop-blur-sm text-amber-300 font-bold">
            🏟️ {match.stadium}
          </div>
        </div>

        {/* ── Duelo visual: Totalmente a la Izquierda vs Totalmente a la Derecha ── */}
        <div className="grid grid-cols-3 items-center py-4">
          {/* Equipo Local (Totalmente a la izquierda) */}
          <div className="flex flex-col items-center sm:items-start text-center sm:text-left">
            <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-2xl bg-white/10 p-3 flex items-center justify-center border border-white/20 shadow-lg backdrop-blur-xs">
              <img
                src={match.homeTeam.logoUrl}
                alt={match.homeTeam.name}
                className="w-full h-full object-contain"
              />
            </div>
            <h2 className="text-lg sm:text-2xl font-black mt-3 tracking-tight">
              {match.homeTeam.name}
            </h2>
            <span className="text-xs font-semibold text-blue-300 uppercase tracking-widest mt-0.5">
              Local
            </span>
          </div>

          {/* Centro: VS y Hora */}
          <div className="flex flex-col items-center justify-center text-center">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-400 text-gray-950 font-black text-xl sm:text-2xl flex items-center justify-center shadow-lg transform hover:rotate-12 transition-transform">
              VS
            </div>
            <span className="text-xs sm:text-sm font-extrabold text-amber-400 mt-2 uppercase tracking-wider">
              {match.time}
            </span>
            <span className="text-[11px] text-gray-400 hidden sm:block">
              {match.location}
            </span>
          </div>

          {/* Equipo Visitante (Totalmente a la derecha) */}
          <div className="flex flex-col items-center sm:items-end text-center sm:text-right">
            <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-2xl bg-white/10 p-3 flex items-center justify-center border border-white/20 shadow-lg backdrop-blur-xs">
              <img
                src={match.awayTeam.logoUrl}
                alt={match.awayTeam.name}
                className="w-full h-full object-contain"
              />
            </div>
            <h2 className="text-lg sm:text-2xl font-black mt-3 tracking-tight">
              {match.awayTeam.name}
            </h2>
            <span className="text-xs font-semibold text-amber-300 uppercase tracking-widest mt-0.5">
              Visitante
            </span>
          </div>
        </div>
      </div>

      {/* ── Transmisión de YouTube en Directo ── */}
      <div className="p-6 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-md">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <span>📺</span> Transmisión Oficial en Directo
          </h2>
          <a
            href="https://www.youtube.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs font-semibold text-red-600 dark:text-red-400 hover:underline flex items-center gap-1"
          >
            Abrir en YouTube ↗
          </a>
        </div>
        <div className="overflow-hidden rounded-xl bg-black aspect-video shadow-inner flex items-center justify-center text-center p-4">
          <iframe
            className="w-full h-full"
            src="https://www.youtube.com/embed/live_stream?channel=win_sports&autoplay=0"
            title="Transmisión del Partido de Fútbol"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
      </div>

      {/* ── Técnicos y Capitanes con Fotos y Nombres ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Cuerpo Técnico y Capitán - Equipo Local */}
        <div className="p-6 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm">
          <h3 className="font-bold text-base text-gray-900 dark:text-white mb-4 pb-2 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between">
            <span>{match.homeTeam.name}</span>
            <span className="text-xs font-normal text-gray-500">Técnico & Capitán</span>
          </h3>

          <div className="grid grid-cols-2 gap-4">
            {/* Foto del Técnico */}
            <div className="flex items-center gap-3 p-3 rounded-xl bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-800">
              <img
                src={match.homeTeam.coachImageUrl}
                alt={match.homeTeam.coach}
                className="w-14 h-14 rounded-full object-cover border-2 border-blue-500"
              />
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                  Director Técnico
                </span>
                <p className="font-bold text-sm text-gray-900 dark:text-white mt-0.5">
                  {match.homeTeam.coach}
                </p>
              </div>
            </div>

            {/* Capitán al lado de su técnico con su nombre */}
            <div className="flex items-center gap-3 p-3 rounded-xl bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-800">
              <img
                src={match.homeTeam.captainImageUrl}
                alt={match.homeTeam.captain}
                className="w-14 h-14 rounded-full object-cover border-2 border-amber-500"
              />
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                  Capitán de Campo Ⓒ
                </span>
                <p className="font-bold text-sm text-gray-900 dark:text-white mt-0.5">
                  {match.homeTeam.captain}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Cuerpo Técnico y Capitán - Equipo Visitante */}
        <div className="p-6 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm">
          <h3 className="font-bold text-base text-gray-900 dark:text-white mb-4 pb-2 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between">
            <span>{match.awayTeam.name}</span>
            <span className="text-xs font-normal text-gray-500">Técnico & Capitán</span>
          </h3>

          <div className="grid grid-cols-2 gap-4">
            {/* Foto del Técnico */}
            <div className="flex items-center gap-3 p-3 rounded-xl bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-800">
              <img
                src={match.awayTeam.coachImageUrl}
                alt={match.awayTeam.coach}
                className="w-14 h-14 rounded-full object-cover border-2 border-blue-500"
              />
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                  Director Técnico
                </span>
                <p className="font-bold text-sm text-gray-900 dark:text-white mt-0.5">
                  {match.awayTeam.coach}
                </p>
              </div>
            </div>

            {/* Capitán al lado de su técnico con su nombre */}
            <div className="flex items-center gap-3 p-3 rounded-xl bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-800">
              <img
                src={match.awayTeam.captainImageUrl}
                alt={match.awayTeam.captain}
                className="w-14 h-14 rounded-full object-cover border-2 border-amber-500"
              />
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                  Capitán de Campo Ⓒ
                </span>
                <p className="font-bold text-sm text-gray-900 dark:text-white mt-0.5">
                  {match.awayTeam.captain}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── Estadio y Compra de Boleta ── */}
      <div className="p-6 bg-gradient-to-r from-emerald-500/10 via-teal-500/5 to-transparent rounded-2xl border-2 border-emerald-500/30 shadow-md">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-950 px-2.5 py-1 rounded-full">
              Boletería Oficial
            </span>
            <h3 className="text-2xl font-black text-gray-900 dark:text-white mt-2">
              Estadio: {match.stadium}
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              Ubicación: <strong className="text-gray-900 dark:text-white">{match.location}</strong>. Entradas electrónicas con código QR inmediato y control biométrico en accesos.
            </p>

            <div className="flex items-center gap-4 mt-3">
              <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">
                Precio de la boleta:
              </span>
              <span className="text-xl font-black text-emerald-600 dark:text-emerald-400">
                {match.price}
              </span>
            </div>
          </div>

          <div className="w-full md:w-auto flex flex-col items-center gap-2">
            {ticketBought ? (
              <div className="p-4 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 rounded-xl text-center font-bold text-sm border border-emerald-300 dark:border-emerald-800">
                ✅ ¡Entrada adquirida con éxito! Tu pase QR ha sido enviado a tu correo.
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setTicketBought(true)}
                className="w-full md:w-auto px-8 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-base rounded-xl shadow-lg hover:shadow-xl transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <span>🎟️</span>
                <span>{match.upcoming ? "Reservar Boleta" : "Comprar Entrada"} ({match.price})</span>
              </button>
            )}
            <span className="text-[11px] text-gray-400 text-center">
              Válido para entrada al estadio {match.stadium}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

