"use client";

import { useState } from "react";
import type { GameEventItem, GameCharacter } from "@/data/events";

interface Props {
  game: GameEventItem;
}

export default function GameInteractiveDetail({ game }: Props) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [selectedCharacter, setSelectedCharacter] = useState<GameCharacter | null>(
    game.characters[0] || null
  );
  const [characterMessage, setCharacterMessage] = useState<string | null>(
    game.characters[0]?.phrase || null
  );
  const [purchased, setPurchased] = useState(false);
  const [format, setFormat] = useState<"digital" | "physical">("digital");

  const images = game.carouselImages && game.carouselImages.length > 0
    ? game.carouselImages
    : [game.coverImage || "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1200"];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % images.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + images.length) % images.length);
  };

  const handleCharacterClick = (char: GameCharacter) => {
    setSelectedCharacter(char);
    setCharacterMessage(char.phrase);
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* ── Carrusel de 5 imágenes del videojuego ── */}
      <div className="relative overflow-hidden rounded-2xl bg-black shadow-2xl aspect-[16/9] border border-gray-200 dark:border-gray-800">
        <img
          src={images[currentSlide]}
          alt={`${game.title} - captura ${currentSlide + 1}`}
          className="w-full h-full object-cover transition-all duration-500"
        />

        {/* Overlay con información */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 pointer-events-none" />

        {/* Controles de anterior y siguiente */}
        <button
          onClick={prevSlide}
          type="button"
          className="absolute left-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-black/60 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-sm transition-transform hover:scale-110 cursor-pointer"
          aria-label="Imagen anterior"
        >
          ❮
        </button>
        <button
          onClick={nextSlide}
          type="button"
          className="absolute right-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-black/60 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-sm transition-transform hover:scale-110 cursor-pointer"
          aria-label="Siguiente imagen"
        >
          ❯
        </button>

        {/* Indicadores de puntos */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-black/50 px-3 py-1.5 rounded-full backdrop-blur-sm">
          {images.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentSlide(idx)}
              className={`h-2.5 rounded-full transition-all cursor-pointer ${
                idx === currentSlide ? "w-7 bg-amber-400" : "w-2.5 bg-white/50 hover:bg-white"
              }`}
              aria-label={`Ir a imagen ${idx + 1}`}
            />
          ))}
        </div>

        <div className="absolute top-4 left-4 bg-amber-500 text-black font-extrabold text-xs uppercase px-3 py-1 rounded-full shadow-md">
          Captura {currentSlide + 1} de {images.length}
        </div>
      </div>

      {/* Miniaturas del carrusel */}
      <div className="grid grid-cols-5 gap-2">
        {images.map((img, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentSlide(idx)}
            className={`rounded-xl overflow-hidden border-2 transition-all aspect-video cursor-pointer ${
              idx === currentSlide
                ? "border-amber-500 scale-102 ring-2 ring-amber-500/50"
                : "border-transparent opacity-60 hover:opacity-100"
            }`}
          >
            <img src={img} alt="Miniatura" className="w-full h-full object-cover" />
          </button>
        ))}
      </div>

      {/* ── Personajes Principales con frases al hacer click ── */}
      <div className="p-6 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-md">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <span>🗡️</span> Personajes Principales
            </h2>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Haz click sobre la foto de cada personaje para escuchar su frase característica:
            </p>
          </div>
          <span className="text-xs bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 px-2.5 py-1 rounded-full font-bold">
            Interactivo
          </span>
        </div>

        {/* Speech Bubble / Frase del personaje activo */}
        {selectedCharacter && characterMessage && (
          <div className="mb-6 p-4 rounded-xl bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border-l-4 border-amber-500 text-gray-900 dark:text-white flex items-start gap-3">
            <span className="text-2xl animate-bounce">💬</span>
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                {selectedCharacter.name} dice:
              </p>
              <p className="text-base font-semibold italic mt-0.5">
                "{characterMessage}"
              </p>
            </div>
          </div>
        )}

        {/* Fotos circulares de los personajes */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
          {game.characters.map((char) => {
            const isSelected = selectedCharacter?.name === char.name;
            return (
              <button
                key={char.name}
                type="button"
                onClick={() => handleCharacterClick(char)}
                className={`group flex flex-col items-center p-3 rounded-2xl transition-all cursor-pointer ${
                  isSelected
                    ? "bg-amber-50 dark:bg-amber-950/40 ring-2 ring-amber-500 shadow-md scale-105"
                    : "hover:bg-gray-50 dark:hover:bg-gray-800/60"
                }`}
              >
                <div className="relative">
                  <img
                    src={char.imageUrl}
                    alt={char.name}
                    className={`w-20 h-20 rounded-full object-cover border-3 transition-transform group-hover:scale-105 ${
                      isSelected
                        ? "border-amber-500 shadow-lg"
                        : "border-gray-300 dark:border-gray-700"
                    }`}
                  />
                  {isSelected && (
                    <span className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-amber-500 text-white text-xs flex items-center justify-center font-bold shadow-xs">
                      ✓
                    </span>
                  )}
                </div>
                <span className="font-bold text-sm text-gray-900 dark:text-white mt-2 text-center group-hover:text-amber-500 transition-colors">
                  {char.name}
                </span>
                <span className="text-[11px] text-gray-400 text-center mt-0.5">
                  Click para frase
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ── Trailer Oficial en YouTube ── */}
      <div className="p-6 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-md">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
          <span>🎬</span> Trailer Oficial de Anuncio
        </h2>
        <div className="overflow-hidden rounded-xl bg-black aspect-video shadow-inner">
          <iframe
            className="w-full h-full"
            src={`https://www.youtube.com/embed/${game.youtubeTrailerId}?autoplay=0&rel=0`}
            title={`${game.title} Trailer`}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
      </div>

      {/* ── Caja de Precios y Preinscripción ── */}
      <div className="p-6 bg-gradient-to-br from-amber-500/10 via-purple-500/5 to-transparent rounded-2xl border-2 border-amber-500/30 shadow-lg">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 bg-amber-100 dark:bg-amber-950 px-2.5 py-1 rounded-full">
              Edición Nintendo Switch 2
            </span>
            <h3 className="text-2xl font-black text-gray-900 dark:text-white mt-2">
              Reserva y Preinscripción Oficial
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1 max-w-xl">
              Asegura tu copia digital o física con bonificaciones de reserva exclusivas (caja metálica coleccionista y banda sonora orquestal digital).
            </p>

            <div className="flex flex-wrap gap-4 mt-4">
              <label
                onClick={() => setFormat("digital")}
                className={`flex items-center gap-2.5 px-4 py-2 rounded-xl border cursor-pointer transition-all ${
                  format === "digital"
                    ? "border-amber-500 bg-amber-50 dark:bg-amber-950/50 font-bold text-gray-900 dark:text-white"
                    : "border-gray-300 dark:border-gray-700 text-gray-600 dark:text-gray-400"
                }`}
              >
                <input
                  type="radio"
                  name="gameFormat"
                  checked={format === "digital"}
                  onChange={() => setFormat("digital")}
                  className="text-amber-500"
                />
                <div>
                  <div className="text-xs uppercase text-gray-500">Precio Digital</div>
                  <div className="text-lg font-black text-blue-600 dark:text-blue-400">{game.price}</div>
                </div>
              </label>

              {game.pricePhysical && (
                <label
                  onClick={() => setFormat("physical")}
                  className={`flex items-center gap-2.5 px-4 py-2 rounded-xl border cursor-pointer transition-all ${
                    format === "physical"
                      ? "border-amber-500 bg-amber-50 dark:bg-amber-950/50 font-bold text-gray-900 dark:text-white"
                      : "border-gray-300 dark:border-gray-700 text-gray-600 dark:text-gray-400"
                  }`}
                >
                  <input
                    type="radio"
                    name="gameFormat"
                    checked={format === "physical"}
                    onChange={() => setFormat("physical")}
                    className="text-amber-500"
                  />
                  <div>
                    <div className="text-xs uppercase text-gray-500">Precio Físico (Cartucho)</div>
                    <div className="text-lg font-black text-purple-600 dark:text-purple-400">{game.pricePhysical}</div>
                  </div>
                </label>
              )}
            </div>
          </div>

          <div className="w-full md:w-auto flex flex-col items-center gap-2">
            {purchased ? (
              <div className="p-4 bg-green-100 dark:bg-green-950 text-green-800 dark:text-green-300 rounded-xl text-center font-bold text-sm border border-green-300 dark:border-green-800">
                🎉 ¡Preinscripción confirmada! Te notificaremos el día de estreno.
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setPurchased(true)}
                className="w-full md:w-auto px-8 py-3.5 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-extrabold text-base rounded-xl shadow-lg hover:shadow-xl transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <span>🛒</span>
                <span>Preinscribirme / Comprar ({format === "digital" ? "Digital" : "Físico"})</span>
              </button>
            )}
            <span className="text-[11px] text-gray-400 text-center">
              Garantía de reembolso hasta el día del lanzamiento
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

