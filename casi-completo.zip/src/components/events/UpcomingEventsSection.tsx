"use client";

import { useState } from "react";
import Link from "next/link";
import type { EventItem } from "@/data/events";

interface Props {
  events: EventItem[];
  isAuthenticated: boolean;
}

const filterOptions = [
  { key: "all", label: "🌟 Todos los Estrenos", icon: "✨" },
  { key: "music", label: "Música & Festivales", icon: "🎵" },
  { key: "games", label: "Videojuegos Switch 2", icon: "🎮" },
  { key: "theatre", label: "Teatro & Obras", icon: "🎭" },
  { key: "football", label: "Fútbol Internacional", icon: "⚽" },
];

export default function UpcomingEventsSection({ events, isAuthenticated }: Props) {
  const [activeCategory, setActiveCategory] = useState("all");

  const filteredEvents = events.filter((ev) => {
    if (!ev.upcoming) return false;
    if (activeCategory === "all") return true;
    return ev.category === activeCategory;
  });

  const getEventDestination = (eventId: string) => {
    if (isAuthenticated) {
      return `/events/${eventId}`;
    }
    // Si no está logueado, redirige al login con parámetro para volver
    return `/login?redirect=/events/${eventId}`;
  };

  return (
    <section id="proximos" className="scroll-mt-24 space-y-6">
      {/* Encabezado */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-gray-200 dark:border-gray-800 pb-4">
        <div>
          <span className="text-xs font-black uppercase tracking-widest text-amber-600 dark:text-amber-400 bg-amber-100 dark:bg-amber-950 px-3 py-1 rounded-full">
            🔥 Cartelera de Próximos Estrenos
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white mt-2">
            Próximos Eventos, Conciertos y Lanzamientos
          </h2>
          <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1 max-w-2xl">
            Descubre los estrenos más esperados de 2026. Filtra por categoría y asegura tus entradas o preinscripciones antes de que se agoten.
          </p>
        </div>

        {/* Botones de Filtro rápido */}
        <div className="flex flex-wrap gap-1.5 p-1 bg-gray-100 dark:bg-gray-800/80 rounded-xl border border-gray-200 dark:border-gray-700">
          {filterOptions.map((opt) => (
            <button
              key={opt.key}
              onClick={() => setActiveCategory(opt.key)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                activeCategory === opt.key
                  ? "bg-white dark:bg-gray-900 text-blue-600 dark:text-blue-400 shadow-xs scale-102"
                  : "text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"
              }`}
            >
              <span>{opt.icon}</span>
              <span>{opt.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Grid de eventos próximos */}
      {filteredEvents.length === 0 ? (
        <div className="p-8 text-center bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800">
          <p className="text-gray-500 text-sm">No hay eventos próximos en esta categoría por ahora.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEvents.map((ev) => {
            const dest = getEventDestination(ev.id);
            return (
              <div
                key={ev.id}
                className="group flex flex-col justify-between overflow-hidden rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 hover:border-amber-500 dark:hover:border-amber-500/80 transition-all duration-300 shadow-md hover:shadow-xl"
              >
                {/* Portada */}
                <div className="relative aspect-video overflow-hidden bg-gray-950">
                  <img
                    src={ev.coverImage || "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800"}
                    alt={ev.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-3 left-3 flex gap-2">
                    <span className="text-[10px] font-black uppercase px-2.5 py-1 rounded-full bg-amber-500 text-black shadow-md">
                      Próximo
                    </span>
                    <span className="text-[10px] font-bold uppercase px-2.5 py-1 rounded-full bg-black/70 text-white backdrop-blur-xs">
                      {ev.category === "music" ? "🎵 Música" : ev.category === "games" ? "🎮 Videojuegos" : ev.category === "theatre" ? "🎭 Teatro" : "⚽ Fútbol"}
                    </span>
                  </div>

                  {ev.price && (
                    <div className="absolute bottom-3 right-3 bg-black/80 backdrop-blur-sm px-2.5 py-1 rounded-lg text-xs font-black text-amber-300">
                      {ev.price}
                    </div>
                  )}
                </div>

                {/* Contenido */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <p className="text-xs font-semibold text-amber-600 dark:text-amber-400">
                      📅 {ev.date}
                    </p>
                    <h3 className="text-lg font-black text-gray-900 dark:text-white mt-1 line-clamp-2 group-hover:text-amber-500 transition-colors">
                      {ev.title}
                    </h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-2 line-clamp-3 leading-relaxed">
                      {ev.description}
                    </p>
                    {"location" in ev && ev.location && (
                      <p className="text-[11px] text-gray-400 mt-2 flex items-center gap-1">
                        📍 {ev.location}
                      </p>
                    )}
                  </div>

                  {/* Botones de acción */}
                  <div className="mt-5 pt-4 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between gap-2">
                    <div className="text-xs">
                      {!isAuthenticated ? (
                        <span className="text-[11px] text-gray-400 font-medium">
                          🔒 Inicia sesión para ingresar
                        </span>
                      ) : (
                        <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold">
                          Acceso desbloqueado
                        </span>
                      )}
                    </div>

                    <Link
                      href={dest}
                      className="px-3.5 py-2 text-xs font-bold rounded-xl bg-amber-500 hover:bg-amber-400 text-black transition-all flex items-center gap-1.5 shadow-sm hover:shadow-md cursor-pointer"
                    >
                      <span>
                        {ev.category === "games"
                          ? "Ver Trailer & Preorden"
                          : ev.category === "football"
                          ? "Reservar Boleta"
                          : "Comprar Boleto"}
                      </span>
                      <span>&rarr;</span>
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}

