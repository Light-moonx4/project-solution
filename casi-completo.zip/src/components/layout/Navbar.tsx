import Link from "next/link";
import { cookies } from "next/headers";
import ThemeToggleButton from "@/components/ui/ThemeToggleButton";

export default async function Navbar() {
  const cookieStore = await cookies();
  const token = cookieStore.get("token")?.value;
  const role = cookieStore.get("role")?.value || "user";
  const userName = cookieStore.get("user_name")?.value;

  const isAdmin = token && role === "admin";

  return (
    <header className="sticky top-0 z-50 backdrop-blur-md bg-white/90 dark:bg-gray-950/90 border-b border-gray-200 dark:border-gray-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand / Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <span className="text-2xl transition-transform group-hover:scale-110">🎪</span>
          <div>
            <span className="font-extrabold text-lg sm:text-xl tracking-tight text-gray-900 dark:text-white">
              Shadow<span className="text-blue-600 dark:text-blue-400">Events</span>
            </span>
          </div>
        </Link>

        {/* Navigation Links */}
        <nav className="hidden md:flex items-center gap-6">
          <Link
            href="/"
            className="text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
          >
            Inicio
          </Link>
          <Link
            href="/events"
            className="text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
          >
            Todos los Eventos
          </Link>
          <Link
            href="/#proximos"
            className="text-sm font-medium text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1 font-semibold"
          >
            <span>🔥</span> Próximos Estrenos
          </Link>
          <Link
            href="/categories"
            className="text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
          >
            Categorías
          </Link>
          {isAdmin && (
            <Link
              href="/admin/events/create"
              className="text-xs font-semibold text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/60 border border-purple-200 dark:border-purple-800 px-2.5 py-1 rounded-full hover:bg-purple-100 transition-colors"
            >
              + Crear Evento
            </Link>
          )}
        </nav>

        {/* Right Section: Theme Toggle & Auth */}
        <div className="flex items-center gap-3">
          <ThemeToggleButton />

          <div className="h-5 w-px bg-gray-200 dark:bg-gray-800 hidden sm:block" />

          {token ? (
            <div className="flex items-center gap-2">
              <Link
                href={isAdmin ? "/admin/dashboard" : "/user/dashboard"}
                className={`text-xs sm:text-sm font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${
                  isAdmin
                    ? "bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300 hover:bg-purple-200"
                    : "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300 hover:bg-blue-200"
                }`}
              >
                <span>{isAdmin ? "👑" : "👤"}</span>
                <span className="hidden sm:inline">
                  {isAdmin ? "Panel Admin" : userName ? `Hola, ${userName}` : "Mi Panel"}
                </span>
                <span className="sm:hidden">{isAdmin ? "Admin" : "Panel"}</span>
              </Link>
              <form action="/api/auth/logout" method="POST">
                <button
                  type="submit"
                  className="text-xs sm:text-sm font-medium px-2.5 py-1.5 rounded-lg text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 transition-colors cursor-pointer"
                  title="Cerrar Sesión"
                >
                  Salir
                </button>
              </form>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link
                href="/login"
                className="text-xs sm:text-sm font-semibold px-3 py-1.5 rounded-lg border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              >
                Iniciar Sesión
              </Link>
              <Link
                href="/register"
                className="text-xs sm:text-sm font-semibold px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white transition-colors shadow-xs"
              >
                Registrarse
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}