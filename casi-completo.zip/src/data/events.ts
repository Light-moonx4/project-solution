export interface BandMember {
  name: string;
  role: string;
  imageUrl: string;
}

export interface GameCharacter {
  name: string;
  imageUrl: string;
  phrase: string;
}

export interface TheaterCharacter {
  name: string;
  actor: string;
  imageUrl: string;
}

export interface FootballTeam {
  name: string;
  logoUrl: string;
  coach: string;
  coachImageUrl: string;
  captain: string;
  captainImageUrl: string;
}

// ─── Interfaces por categoría ───

export interface MusicEventItem {
  id: string;
  title: string;
  category: "music";
  date: string;
  location: string;
  description: string;
  youtubeId?: string;
  bandMembers?: BandMember[];
  price?: string;
  upcoming?: boolean;
  coverImage?: string;
}

export interface GameEventItem {
  id: string;
  title: string;
  category: "games";
  date: string;
  location?: string;
  description: string;
  price: string;
  pricePhysical?: string;
  youtubeTrailerId: string;
  carouselImages: string[];
  characters: GameCharacter[];
  upcoming?: boolean;
  preorder?: boolean;
  coverImage?: string;
}

export interface TheaterEventItem {
  id: string;
  title: string;
  category: "theatre";
  date: string;
  location: string;
  description: string;
  imageUrl: string;
  characters: TheaterCharacter[];
  price: string;
  upcoming?: boolean;
  coverImage?: string;
}

export interface FootballEventItem {
  id: string;
  title: string;
  category: "football";
  date: string;
  time: string;
  location: string;
  stadium: string;
  description: string;
  youtubeStreamId?: string;
  homeTeam: FootballTeam;
  awayTeam: FootballTeam;
  price: string;
  upcoming?: boolean;
  isLive?: boolean;
  coverImage?: string;
}

export type EventItem =
  | MusicEventItem
  | GameEventItem
  | TheaterEventItem
  | FootballEventItem;

// ─── Colección de Eventos iniciales ───

export let eventsData: EventItem[] = [
  // ── 1. MÚSICA - EN CARTELERA ──
  {
    id: "linkin-park-in-the-end",
    title: "Linkin Park - In The End",
    category: "music",
    date: "15 de Septiembre de 2024",
    location: "Madison Square Garden, New York, NY",
    description: "Una noche legendaria donde Linkin Park interpreta su himno generacional 'In The End' con toda la fuerza del rock alternativo y arreglos sinfónicos en vivo.",
    youtubeId: "eVTXPUF4Oz4",
    price: "$75 USD",
    upcoming: false,
    coverImage: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&auto=format&fit=crop&q=80",
    bandMembers: [
      { name: "Chester Bennington", role: "Voz Principal", imageUrl: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=200&h=200&fit=crop&crop=face" },
      { name: "Mike Shinoda", role: "Voz, Guitarra Rítmica, Teclados", imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face" },
      { name: "Brad Delson", role: "Guitarra Solista", imageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=face" },
      { name: "Dave Phoenix Farrell", role: "Bajo", imageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=face" },
      { name: "Rob Bourdon", role: "Batería", imageUrl: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop&crop=face" },
      { name: "Joe Hahn", role: "Tornamesas, Efectos", imageUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop&crop=face" }
    ]
  },
  {
    id: "skillet-monster",
    title: "Skillet - Monster",
    category: "music",
    date: "20 de Octubre de 2024",
    location: "Hollywood Bowl, Los Angeles, CA",
    description: "La banda de rock Skillet despliega toda su pirotecnia y energía electrizante interpretando 'Monster', su éxito más aclamado a nivel mundial.",
    youtubeId: "1mjlM_RnsVE",
    price: "$65 USD",
    upcoming: false,
    coverImage: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800&auto=format&fit=crop&q=80",
    bandMembers: [
      { name: "John Cooper", role: "Voz Principal, Bajo", imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face" },
      { name: "Korey Cooper", role: "Guitarra Rítmica, Teclados", imageUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop&crop=face" },
      { name: "Jen Ledger", role: "Batería, Coros", imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=face" },
      { name: "Seth Morrison", role: "Guitarra Solista", imageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=face" }
    ]
  },
  {
    id: "evanescence-bring-me-to-life",
    title: "Evanescence - Bring Me To Life",
    category: "music",
    date: "15 de Noviembre de 2024",
    location: "The Forum, Los Angeles, CA",
    description: "Amy Lee conmueve al público con la imponente potencia vocal de 'Bring Me To Life', acompañada de sintetizadores y guitarras góticas.",
    youtubeId: "3YxaaGgTQYM",
    price: "$80 USD",
    upcoming: false,
    coverImage: "https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=800&auto=format&fit=crop&q=80",
    bandMembers: [
      { name: "Amy Lee", role: "Voz Principal, Piano", imageUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop&crop=face" },
      { name: "Troy McLawhorn", role: "Guitarra Solista", imageUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop&crop=face" },
      { name: "Tim McCord", role: "Guitarra", imageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=face" },
      { name: "Will Hunt", role: "Batería", imageUrl: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop&crop=face" }
    ]
  },
  // ── MÚSICA - PRÓXIMO ESTRENO REQUERIDO ──
  {
    id: "bloomsburg-fair-2026",
    title: "Bloomsburg Fair",
    category: "music",
    date: "28 de septiembre de 2026 a las 20:00",
    location: "Bloomsburg, PA, Estados Unidos",
    description: "El tradicional y multitudinario festival musical y cultural Bloomsburg Fair 2026 reúne a artistas de primer nivel internacional en un fin de semana épico. Un espectáculo al aire libre inigualable con gastronomía, atracciones y los mejores conciertos nocturnos.",
    price: "$55.00 USD",
    upcoming: true,
    coverImage: "https://images.unsplash.com/photo-1429962714451-bb934ecdc4ec?w=800&auto=format&fit=crop&q=80",
    bandMembers: [
      { name: "Headliner Band", role: "Banda Principal", imageUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=200&h=200&fit=crop&crop=face" },
      { name: "Orquesta Sinfónica PA", role: "Música de Cámara y Solistas", imageUrl: "https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=200&h=200&fit=crop&crop=face" }
    ]
  },

  // ── 2. VIDEOJUEGOS - PRÓXIMO LANZAMIENTO REQUERIDO ──
  {
    id: "zelda-ocarina-remake-switch2",
    title: "The Legend of Zelda: Ocarina of Time Remake",
    category: "games",
    date: "Finales de 2026 (Lanzamiento Nintendo Switch 2)",
    location: "Nintendo eShop & Tiendas Físicas Oficiales",
    description: "El aclamado e histórico remake de The Legend of Zelda: Ocarina of Time ha sido reconstruido desde cero con un motor gráfico de última generación para Nintendo Switch 2. Incluye iluminación por trazado de rayos, orquestación completa grabada en vivo, controles hápticos HD y la conmovedora aventura que marcó para siempre la historia de los videojuegos.",
    price: "$59.99 USD / 59,99 €",
    pricePhysical: "$69.99 USD / 69,99 €",
    youtubeTrailerId: "TSmJEZoVHTk",
    upcoming: true,
    preorder: true,
    coverImage: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&auto=format&fit=crop&q=80",
    carouselImages: [
      "https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?w=1200&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=1200&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=1200&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1200&auto=format&fit=crop&q=80"
    ],
    characters: [
      {
        name: "Link",
        imageUrl: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=200&h=200&fit=crop&crop=face",
        phrase: "¡Hyaaah! ¡El coraje de la Trifuerza nunca se extingue!"
      },
      {
        name: "Princesa Zelda",
        imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=face",
        phrase: "El destino de Hyrule descansa en tus manos, Héroe del Tiempo."
      },
      {
        name: "Ganondorf",
        imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face",
        phrase: "¡Tiemblen ante el Rey de las Tinieblas! ¡El poder absoluto me pertenece!"
      },
      {
        name: "Navi el Hada",
        imageUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&h=200&fit=crop&crop=face",
        phrase: "¡Hey! ¡Listen! ¡Cuidado con el enemigo que se aproxima!"
      },
      {
        name: "Sheik",
        imageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=face",
        phrase: "El flujo del tiempo es siempre cruel... como el agua que corre, nadie puede detenerlo."
      }
    ]
  },

  // ── 3. TEATRO - CARTELERA ACTUAL Y PRÓXIMAS OBRAS REQUERIDAS ──
  {
    id: "romeo-y-julieta",
    title: "Romeo y Julieta",
    category: "theatre",
    date: "En cartelera actual - Funciones diarias 19:30",
    location: "Teatro Nacional Mayor",
    description: "La inmortal tragedia de William Shakespeare que narra la desdichada historia de amor de dos jóvenes amantes de Verona, cuyas muertes finalmente reconcilian a sus familias en discordia.",
    imageUrl: "https://images.unsplash.com/photo-1507676184212-d03ab07a01bf?w=800&auto=format&fit=crop&q=80",
    coverImage: "https://images.unsplash.com/photo-1507676184212-d03ab07a01bf?w=800&auto=format&fit=crop&q=80",
    price: "$35.000 COP",
    upcoming: false,
    characters: [
      { name: "Romeo Montesco", actor: "Carlos Rivera", imageUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop&crop=face" },
      { name: "Julieta Capuleto", actor: "Sofía Vergara", imageUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop&crop=face" },
      { name: "Mercucio", actor: "Diego Trujillo", imageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=face" },
      { name: "Fray Lorenzo", actor: "Héctor Forero", imageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=face" }
    ]
  },
  {
    id: "jury-experience-robo-20-millones",
    title: "The Jury Experience: El Robo de los 20 Millones de Dólares",
    category: "theatre",
    date: "25 de septiembre de 2026",
    location: "Teatro Universitario José Consuegra Higgins",
    description: "Una experiencia inmersiva e interactiva sin precedentes: el público asistente conforma el jurado que decidirá el veredicto en tiempo real del caso judicial más polémico del siglo sobre el robo de 20 millones de dólares.",
    imageUrl: "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=800&auto=format&fit=crop&q=80",
    coverImage: "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=800&auto=format&fit=crop&q=80",
    price: "$40.000 COP",
    upcoming: true,
    characters: [
      { name: "El Juez Principal", actor: "Manuel Beltrán", imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face" },
      { name: "Fiscal de la Nación", actor: "Elena Restrepo", imageUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&h=200&fit=crop&crop=face" },
      { name: "El Sospechoso Clave", actor: "Sebastián Eslava", imageUrl: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop&crop=face" }
    ]
  },
  {
    id: "fragmentado-obra",
    title: "Fragmentado",
    category: "theatre",
    date: "25 de septiembre de 2026",
    location: "Teatro Universitario José Consuegra Higgins",
    description: "Adaptación teatral dramática de alta tensión psicológica. Explora las 24 personalidades en disputa dentro de una mente desbordada y el misterio latente de la bestia interior.",
    imageUrl: "https://images.unsplash.com/photo-1503095396549-807759245b35?w=800&auto=format&fit=crop&q=80",
    coverImage: "https://images.unsplash.com/photo-1503095396549-807759245b35?w=800&auto=format&fit=crop&q=80",
    price: "$40.000 COP",
    upcoming: true,
    characters: [
      { name: "Kevin Wendell Crumb", actor: "Felipe Botero", imageUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop&crop=face" },
      { name: "Dra. Karen Fletcher", actor: "Patricia Tamayo", imageUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop&crop=face" },
      { name: "Casey Cooke", actor: "Natalia Reyes", imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=face" }
    ]
  },

  // ── 4. FÚTBOL - PARTIDO DE HOY Y PRÓXIMO PARTIDO REQUERIDOS ──
  {
    id: "boyaca-chico-vs-deportivo-pasto",
    title: "Boyacá Chicó vs Deportivo Pasto",
    category: "football",
    date: "Hoy - 25 de septiembre de 2026",
    time: "6:10 PM",
    location: "Tunja, Boyacá, Colombia",
    stadium: "Estadio La Independencia (Tunja)",
    description: "Encuentro vibrante por la Liga de Primera División. Boyacá Chicó defiende su fortín en la altura de Tunja frente a un Deportivo Pasto que llega decidido a sumar los tres puntos.",
    youtubeStreamId: "live_football_stream",
    price: "$25.000 COP - $45.000 COP",
    upcoming: false,
    isLive: true,
    coverImage: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=800&auto=format&fit=crop&q=80",
    homeTeam: {
      name: "Boyacá Chicó FC",
      logoUrl: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=200&auto=format&fit=crop&q=80",
      coach: "Jhon Jaime Gómez",
      coachImageUrl: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=200&h=200&fit=crop&crop=face",
      captain: "Frank Lozano",
      captainImageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face"
    },
    awayTeam: {
      name: "Deportivo Pasto",
      logoUrl: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=200&auto=format&fit=crop&q=80",
      coach: "Gustavo Florentín",
      coachImageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=face",
      captain: "Camilo Ayala",
      captainImageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=face"
    }
  },
  {
    id: "colombia-vs-mexico-amistoso",
    title: "Colombia vs. México - Amistoso Internacional",
    category: "football",
    date: "Próximamente - Octubre 2026",
    time: "8:00 PM",
    location: "Baltimore, Maryland, Estados Unidos",
    stadium: "Bank Stadium de Baltimore",
    description: "Duelo de gigantes continentales: la Selección Colombia se enfrenta a la Selección de México en un emocionante Amistoso Internacional en el Bank Stadium de Baltimore con figuras estelares mundiales.",
    price: "$60 USD - $84 USD",
    upcoming: true,
    coverImage: "https://images.unsplash.com/photo-1489944440615-453fc2b6a9a9?w=800&auto=format&fit=crop&q=80",
    homeTeam: {
      name: "Selección Colombia",
      logoUrl: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=200&auto=format&fit=crop&q=80",
      coach: "Néstor Lorenzo",
      coachImageUrl: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=200&h=200&fit=crop&crop=face",
      captain: "James Rodríguez",
      captainImageUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop&crop=face"
    },
    awayTeam: {
      name: "Selección México",
      logoUrl: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=200&auto=format&fit=crop&q=80",
      coach: "Javier Aguirre",
      coachImageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=face",
      captain: "Edson Álvarez",
      captainImageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=face"
    }
  }
];

// ─── Funciones Helper para CRUD y consultas ───

export function getEvents(): EventItem[] {
  return eventsData;
}

export function getEventById(id: string): EventItem | undefined {
  return eventsData.find((e) => e.id === id);
}

export function getEventsByCategory(category: string): EventItem[] {
  if (!category || category === "all") return eventsData;
  return eventsData.filter((e) => e.category === category);
}

export function getUpcomingEvents(category?: string): EventItem[] {
  const filtered = eventsData.filter((e) => e.upcoming === true);
  if (!category || category === "all") return filtered;
  return filtered.filter((e) => e.category === category);
}

export function getCurrentEvents(category?: string): EventItem[] {
  const filtered = eventsData.filter((e) => !e.upcoming);
  if (!category || category === "all") return filtered;
  return filtered.filter((e) => e.category === category);
}

export function addEvent(event: EventItem): void {
  eventsData.unshift(event);
}

export function updateEvent(id: string, updated: Partial<EventItem>): boolean {
  const index = eventsData.findIndex((e) => e.id === id);
  if (index !== -1) {
    eventsData[index] = { ...eventsData[index], ...updated } as EventItem;
    return true;
  }
  return false;
}

export function deleteEvent(id: string): boolean {
  const index = eventsData.findIndex((e) => e.id === id);
  if (index !== -1) {
    eventsData.splice(index, 1);
    return true;
  }
  return false;
}