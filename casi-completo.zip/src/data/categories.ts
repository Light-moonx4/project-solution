export interface CategoryItem {
  id: string;
  name: string;
  slug: string;
  description?: string;
  icon?: string;
}

export let categoriesData: CategoryItem[] = [
  { id: "all", name: "Todos los Eventos", slug: "all", description: "Explora todas las categorías y estrenos disponibles.", icon: "🎪" },
  { id: "music", name: "Música", slug: "music", description: "Conciertos legendarios, estrenos y bandas en vivo.", icon: "🎵" },
  { id: "games", name: "Videojuegos", slug: "games", description: "Próximos lanzamientos, trailers y personajes icónicos.", icon: "🎮" },
  { id: "theatre", name: "Teatro", slug: "theatre", description: "Obras clásicas, drama contemporáneo y experiencias inmersivas.", icon: "🎭" },
  { id: "football", name: "Fútbol", slug: "football", description: "Partidos en vivo, amistosos internacionales y clásicos.", icon: "⚽" },
];

export function getCategories(): CategoryItem[] {
  return categoriesData;
}

export function getCategoryBySlug(slug: string): CategoryItem | undefined {
  return categoriesData.find((c) => c.slug === slug || c.id === slug);
}

export function addCategory(category: CategoryItem): void {
  categoriesData.push(category);
}

export function updateCategory(id: string, updated: Partial<CategoryItem>): boolean {
  const index = categoriesData.findIndex((c) => c.id === id || c.slug === id);
  if (index !== -1) {
    categoriesData[index] = { ...categoriesData[index], ...updated };
    return true;
  }
  return false;
}

export function deleteCategory(id: string): boolean {
  const index = categoriesData.findIndex((c) => c.id === id || c.slug === id);
  if (index !== -1) {
    categoriesData.splice(index, 1);
    return true;
  }
  return false;
}