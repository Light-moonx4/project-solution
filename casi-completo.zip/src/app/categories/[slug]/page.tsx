import Link from "next/link";
import { cookies } from "next/headers";
import { eventsData } from "@/data/events";
import { categoriesData } from "@/data/categories";

interface CategoryDetailPageProps {
  params: Promise<{ slug: string }>;
}

export default async function CategoryDetailPage({ params }: CategoryDetailPageProps) {
  const { slug } = await params;
  const category = categoriesData.find((item) => item.slug === slug || item.id === slug);
  const events = eventsData.filter((event) => event.category === slug);

  const cookieStore = await cookies();
  const token = cookieStore.get("token")?.value;
  const isAuthenticated = Boolean(token);

  const getEventLink = (id: string) => {
    if (isAuthenticated) return `/events/${id}`;
    return `/login?redirect=/events/${id}`;
  };

  return (
    <div className="mx-auto max-w-4xl p-4 sm:p-6 lg:p-8 text-gray-900 dark:text-white space-y-6">
      <div className="p-6 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-sm">
        <div className="flex items-center gap-3">
          <span className="text-4xl">{category?.icon || "📁"}</span>
          <div>
            <h1 className="text-3xl font-black capitalize">
              Categoría: {category?.name ?? slug}
            </h1>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              {category?.description || "Listado de eventos pertenecientes a esta categoría."}
            </p>
          </div>
        </div>

        <p className="text-xs font-semibold text-blue-600 dark:text-blue-400 mt-4">
          {events.length > 0
            ? `Se encontraron ${events.length} evento(s) disponibles.`
            : "No hay eventos registrados en esta categoría todavía."}
        </p>
      </div>

      {events.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {events.map((event) => (
            <Link
              key={event.id}
              href={getEventLink(event.id)}
              className="group p-5 rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 hover:border-blue-500 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-bold uppercase text-blue-600 dark:text-blue-400">
                    {event.upcoming ? "🔥 Próximo" : "En Cartelera"}
                  </span>
                  {"price" in event && event.price && (
                    <span className="text-xs font-black text-gray-900 dark:text-white">
                      {event.price}
                    </span>
                  )}
                </div>
                <h3 className="font-bold text-base text-gray-900 dark:text-white group-hover:text-blue-600 transition-colors">
                  {event.title}
                </h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-2 line-clamp-2">
                  {event.description}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between text-xs font-semibold">
                <span className="text-gray-400 text-[11px]">
                  {isAuthenticated ? "Ver Detalle" : "🔒 Iniciar sesión"}
                </span>
                <span className="text-blue-500 group-hover:translate-x-1 transition-transform">
                  &rarr;
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}

      <div className="pt-4 flex gap-4">
        <Link href="/categories" className="text-blue-500 hover:underline text-sm font-semibold">
          &larr; Volver a Categorías
        </Link>
        <Link href={`/events?category=${slug}`} className="text-blue-500 hover:underline text-sm font-semibold">
          Ver en el Catálogo Completo &rarr;
        </Link>
      </div>
    </div>
  );
}
