import Link from "next/link";
import { cookies } from "next/headers";
import { eventsData } from "@/data/events";

export default async function UserDashboardPage() {
  const cookieStore = await cookies();
  const userName = cookieStore.get("user_name")?.value || "Usuario";
  const upcomingEvents = eventsData.filter((e) => e.upcoming);

  return (
    <div className="mx-auto max-w-6xl p-4 sm:p-6 lg:p-8 text-gray-900 dark:text-white space-y-8">
      {/* Encabezado */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-6 border-gray-200 dark:border-gray-800">
        <div>
          <span className="text-xs font-black uppercase px-3 py-1 bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300 rounded-full">
            👤 Panel del Miembro
          </span>
          <h1 className="text-3xl font-black mt-2 tracking-tight">
            Hola, {userName}
          </h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Tu cuenta tiene acceso completo a transmisiones en directo, videos de bandas y preventa de boletos.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/events"
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all shadow-sm"
          >
            Explorar Catálogo
          </Link>
          <Link
            href="/#proximos"
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black rounded-xl text-xs font-bold transition-all shadow-sm"
          >
            🔥 Próximos Estrenos
          </Link>
        </div>
      </div>

      {/* Tarjetas de estado */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="p-6 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-sm">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500">
            Membresía
          </h3>
          <p className="text-2xl font-black mt-2 text-emerald-600 dark:text-emerald-400">
            Activa (Pase General)
          </p>
          <span className="text-[11px] text-gray-400">Acceso a videos y directos</span>
        </div>

        <div className="p-6 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-sm">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500">
            Preventas Disponibles
          </h3>
          <p className="text-2xl font-black mt-2 text-amber-500">
            {upcomingEvents.length} Eventos
          </p>
          <span className="text-[11px] text-gray-400">Zelda Switch 2, Bloomsburg Fair, etc.</span>
        </div>

        <div className="p-6 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-sm">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500">
            Partidos en Vivo Hoy
          </h3>
          <p className="text-2xl font-black mt-2 text-blue-600 dark:text-blue-400">
            1 Transmisión
          </p>
          <span className="text-[11px] text-gray-400">Boyacá Chicó vs Pasto 6:10 PM</span>
        </div>
      </div>

      {/* Accesos Rápidos a los Eventos Clave */}
      <div className="p-6 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-sm space-y-4">
        <h2 className="text-xl font-bold">Eventos Recomendados para Ti</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <Link
            href="/events/boyaca-chico-vs-deportivo-pasto"
            className="p-4 rounded-xl border border-gray-200 dark:border-gray-800 hover:border-blue-500 transition-all bg-gray-50 dark:bg-gray-800/40 group"
          >
            <span className="text-2xl">⚽</span>
            <h4 className="font-bold text-sm mt-2 group-hover:text-blue-500 transition-colors">
              Boyacá Chicó vs Pasto
            </h4>
            <p className="text-xs text-gray-500 mt-1">Hoy 6:10 PM • En vivo</p>
          </Link>

          <Link
            href="/events/zelda-ocarina-remake-switch2"
            className="p-4 rounded-xl border border-gray-200 dark:border-gray-800 hover:border-amber-500 transition-all bg-gray-50 dark:bg-gray-800/40 group"
          >
            <span className="text-2xl">🎮</span>
            <h4 className="font-bold text-sm mt-2 group-hover:text-amber-500 transition-colors">
              Zelda: Ocarina Remake
            </h4>
            <p className="text-xs text-gray-500 mt-1">Nintendo Switch 2 • Preorden</p>
          </Link>

          <Link
            href="/events/bloomsburg-fair-2026"
            className="p-4 rounded-xl border border-gray-200 dark:border-gray-800 hover:border-blue-500 transition-all bg-gray-50 dark:bg-gray-800/40 group"
          >
            <span className="text-2xl">🎵</span>
            <h4 className="font-bold text-sm mt-2 group-hover:text-blue-500 transition-colors">
              Bloomsburg Fair 2026
            </h4>
            <p className="text-xs text-gray-500 mt-1">28 Septiembre • Boletos USD</p>
          </Link>

          <Link
            href="/events/romeo-y-julieta"
            className="p-4 rounded-xl border border-gray-200 dark:border-gray-800 hover:border-purple-500 transition-all bg-gray-50 dark:bg-gray-800/40 group"
          >
            <span className="text-2xl">🎭</span>
            <h4 className="font-bold text-sm mt-2 group-hover:text-purple-500 transition-colors">
              Romeo y Julieta
            </h4>
            <p className="text-xs text-gray-500 mt-1">En Cartelera • Elenco en vivo</p>
          </Link>
        </div>
      </div>
    </div>
  );
}