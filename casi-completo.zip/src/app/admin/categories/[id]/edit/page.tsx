"use client";

import { useState, useEffect, use } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

interface Props {
  params: Promise<{ id: string }>;
}

export default function EditCategoryPage({ params }: Props) {
  const { id } = use(params);
  const router = useRouter();

  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [description, setDescription] = useState("");
  const [icon, setIcon] = useState("📁");
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch(`/api/categories/${id}`)
      .then((res) => {
        if (!res.ok) throw new Error("Categoría no encontrada");
        return res.json();
      })
      .then((data) => {
        setName(data.name || "");
        setSlug(data.slug || "");
        setDescription(data.description || "");
        setIcon(data.icon || "📁");
      })
      .catch((err) => setError(err.message))
      .finally(() => setFetching(false));
  }, [id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch(`/api/categories/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, slug, description, icon }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Error al actualizar");

      router.push("/admin/dashboard");
      router.refresh();
    } catch (err: any) {
      setError(err.message || "Ocurrió un error");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm("¿Seguro que deseas eliminar esta categoría?")) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/categories/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Error al eliminar");
      router.push("/admin/dashboard");
      router.refresh();
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  if (fetching) {
    return (
      <div className="mx-auto max-w-2xl p-12 text-center text-sm text-gray-500">
        Cargando datos de la categoría...
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl p-4 sm:p-6 lg:p-8">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <Link
            href="/admin/dashboard"
            className="text-xs text-blue-500 hover:underline font-semibold"
          >
            &larr; Volver al Panel Admin
          </Link>
          <h1 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white mt-2">
            Editar Categoría: {name}
          </h1>
        </div>

        <button
          type="button"
          onClick={handleDelete}
          disabled={loading}
          className="px-3.5 py-2 text-xs font-bold text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-900 rounded-xl hover:bg-red-100 transition-colors cursor-pointer"
        >
          🗑️ Eliminar
        </button>
      </div>

      <div className="p-6 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-lg">
        {error && (
          <div className="mb-4 p-3 text-xs bg-red-100 text-red-600 dark:bg-red-950 dark:text-red-400 rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="sm:col-span-1">
              <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                Icono Emoji
              </label>
              <input
                type="text"
                value={icon}
                onChange={(e) => setIcon(e.target.value)}
                maxLength={4}
                className="w-full text-center text-2xl px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div className="sm:col-span-3">
              <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                Nombre de la Categoría
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-900 dark:text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
              Slug URL
            </label>
            <input
              type="text"
              value={slug}
              onChange={(e) => setSlug(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
              Descripción
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-900 dark:text-white"
            />
          </div>

          <div className="pt-4 flex items-center justify-end gap-3">
            <Link
              href="/admin/dashboard"
              className="px-4 py-2.5 border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 text-sm font-semibold rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            >
              Cancelar
            </Link>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-sm rounded-xl shadow-md transition-colors cursor-pointer"
            >
              {loading ? "Guardando..." : "Actualizar Categoría"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

