"use client";

import { useState, useEffect, use } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { categoriesData } from "@/data/categories";
import type { GameCharacter, BandMember, TheaterCharacter, FootballTeam } from "@/data/events";

interface Props {
  params: Promise<{ id: string }>;
}

export default function EditEventPage({ params }: Props) {
  const { id } = use(params);
  const router = useRouter();

  // Campos Generales
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("music");
  const [date, setDate] = useState("");
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [coverImage, setCoverImage] = useState("");
  const [upcoming, setUpcoming] = useState(false);

  // Campos Específicos de Videojuegos
  const [youtubeTrailerId, setYoutubeTrailerId] = useState("");
  const [pricePhysical, setPricePhysical] = useState("");
  const [carouselImages, setCarouselImages] = useState<string[]>([
    "", "", "", "", ""
  ]);
  const [gameCharacters, setGameCharacters] = useState<GameCharacter[]>([
    { name: "", imageUrl: "", phrase: "" }
  ]);

  // Campos Específicos de Música
  const [musicYoutubeId, setMusicYoutubeId] = useState("");
  const [bandMembers, setBandMembers] = useState<BandMember[]>([
    { name: "", role: "", imageUrl: "" }
  ]);

  // Campos Específicos de Teatro
  const [theaterImage, setTheaterImage] = useState("");
  const [theaterCharacters, setTheaterCharacters] = useState<TheaterCharacter[]>([
    { name: "", actor: "", imageUrl: "" }
  ]);

  // Campos Específicos de Fútbol
  const [stadium, setStadium] = useState("");
  const [matchTime, setMatchTime] = useState("");
  const [youtubeStreamId, setYoutubeStreamId] = useState("");
  const [homeTeam, setHomeTeam] = useState<FootballTeam>({
    name: "",
    logoUrl: "",
    coach: "",
    coachImageUrl: "",
    captain: "",
    captainImageUrl: "",
  });
  const [awayTeam, setAwayTeam] = useState<FootballTeam>({
    name: "",
    logoUrl: "",
    coach: "",
    coachImageUrl: "",
    captain: "",
    captainImageUrl: "",
  });

  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch(`/api/events/${id}`)
      .then((res) => {
        if (!res.ok) throw new Error("Evento no encontrado");
        return res.json();
      })
      .then((data) => {
        setTitle(data.title || "");
        setCategory(data.category || "music");
        setDate(data.date || "");
        setLocation(data.location || "");
        setDescription(data.description || "");
        setPrice(data.price || "");
        setCoverImage(data.coverImage || "");
        setUpcoming(Boolean(data.upcoming));

        // Cargar Videojuegos
        if (data.youtubeTrailerId) setYoutubeTrailerId(data.youtubeTrailerId);
        if (data.pricePhysical) setPricePhysical(data.pricePhysical);
        if (data.carouselImages && Array.isArray(data.carouselImages)) {
          const imgs = [...data.carouselImages];
          while (imgs.length < 5) imgs.push("");
          setCarouselImages(imgs.slice(0, 5));
        }
        if (data.characters && Array.isArray(data.characters)) {
          if (data.category === "games") {
            setGameCharacters(data.characters);
          } else if (data.category === "theatre") {
            setTheaterCharacters(data.characters);
          }
        }

        // Cargar Música
        if (data.youtubeId) setMusicYoutubeId(data.youtubeId);
        if (data.bandMembers && Array.isArray(data.bandMembers)) {
          setBandMembers(data.bandMembers);
        }

        // Cargar Teatro
        if (data.imageUrl) setTheaterImage(data.imageUrl);

        // Cargar Fútbol
        if (data.stadium) setStadium(data.stadium);
        if (data.time) setMatchTime(data.time);
        if (data.youtubeStreamId) setYoutubeStreamId(data.youtubeStreamId);
        if (data.homeTeam) setHomeTeam(data.homeTeam);
        if (data.awayTeam) setAwayTeam(data.awayTeam);
      })
      .catch((err) => setError(err.message))
      .finally(() => setFetching(false));
  }, [id]);

  // Manejadores para Carrusel
  const handleCarouselChange = (index: number, val: string) => {
    const updated = [...carouselImages];
    updated[index] = val;
    setCarouselImages(updated);
  };

  // Manejadores para Personajes de Juegos
  const handleGameCharacterChange = (index: number, field: keyof GameCharacter, val: string) => {
    const updated = [...gameCharacters];
    updated[index] = { ...updated[index], [field]: val };
    setGameCharacters(updated);
  };
  const addGameCharacter = () => {
    setGameCharacters([...gameCharacters, { name: "", imageUrl: "", phrase: "" }]);
  };
  const removeGameCharacter = (index: number) => {
    setGameCharacters(gameCharacters.filter((_, i) => i !== index));
  };

  // Manejadores para Miembros de Banda
  const handleBandMemberChange = (index: number, field: keyof BandMember, val: string) => {
    const updated = [...bandMembers];
    updated[index] = { ...updated[index], [field]: val };
    setBandMembers(updated);
  };
  const addBandMember = () => {
    setBandMembers([...bandMembers, { name: "", role: "", imageUrl: "" }]);
  };
  const removeBandMember = (index: number) => {
    setBandMembers(bandMembers.filter((_, i) => i !== index));
  };

  // Manejadores para Teatro
  const handleTheaterCharacterChange = (index: number, field: keyof TheaterCharacter, val: string) => {
    const updated = [...theaterCharacters];
    updated[index] = { ...updated[index], [field]: val };
    setTheaterCharacters(updated);
  };
  const addTheaterCharacter = () => {
    setTheaterCharacters([...theaterCharacters, { name: "", actor: "", imageUrl: "" }]);
  };
  const removeTheaterCharacter = (index: number) => {
    setTheaterCharacters(theaterCharacters.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const payload: any = {
        title,
        category,
        date,
        location,
        description,
        price,
        coverImage,
        upcoming,
      };

      if (category === "games") {
        payload.youtubeTrailerId = youtubeTrailerId;
        payload.pricePhysical = pricePhysical;
        // Filtrar carrusel sin espacios vacíos o dejar array
        payload.carouselImages = carouselImages.filter((url) => url.trim().length > 0);
        payload.characters = gameCharacters.filter((c) => c.name.trim().length > 0);
      } else if (category === "music") {
        payload.youtubeId = musicYoutubeId;
        payload.bandMembers = bandMembers.filter((m) => m.name.trim().length > 0);
      } else if (category === "theatre") {
        payload.imageUrl = theaterImage || coverImage;
        payload.characters = theaterCharacters.filter((c) => c.name.trim().length > 0);
      } else if (category === "football") {
        payload.stadium = stadium || location;
        payload.time = matchTime || "6:10 PM";
        payload.youtubeStreamId = youtubeStreamId;
        payload.homeTeam = homeTeam;
        payload.awayTeam = awayTeam;
      }

      const res = await fetch(`/api/events/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Error al actualizar evento");

      router.push(`/events/${id}`);
      router.refresh();
    } catch (err: any) {
      setError(err.message || "Ocurrió un error");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm("¿Estás seguro de que deseas eliminar este evento del catálogo?")) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/events/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Error al eliminar evento");
      router.push("/events");
      router.refresh();
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  if (fetching) {
    return (
      <div className="mx-auto max-w-3xl p-12 text-center text-sm text-gray-500">
        Cargando datos del evento...
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl p-4 sm:p-6 lg:p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <Link
            href="/admin/dashboard"
            className="text-xs text-blue-500 hover:underline font-semibold"
          >
            ← Volver al Panel Admin
          </Link>
          <h1 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white mt-2">
            Editar Evento: {title}
          </h1>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
            Modifica todos los campos principales y específicos por categoría (carruseles, personajes, directores técnicos, estadios, etc.)
          </p>
        </div>

        <button
          type="button"
          onClick={handleDelete}
          disabled={loading}
          className="px-3.5 py-2 text-xs font-bold text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-900 rounded-xl hover:bg-red-100 transition-colors cursor-pointer"
        >
          🗑️ Eliminar Evento
        </button>
      </div>

      <div className="p-6 sm:p-8 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-xl">
        {error && (
          <div className="mb-4 p-3 text-xs bg-red-100 text-red-600 dark:bg-red-950 dark:text-red-400 rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* ── DATOS GENERALES ── */}
          <div className="border-b border-gray-200 dark:border-gray-800 pb-5 space-y-4">
            <h2 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <span>📋</span> Información General
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                  Título del Evento
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                  className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                  Categoría
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white"
                >
                  {categoriesData.filter((c) => c.slug !== "all").map((cat) => (
                    <option key={cat.slug} value={cat.slug} className="dark:bg-gray-900">
                      {cat.icon || "📁"} {cat.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                  Fecha
                </label>
                <input
                  type="text"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                  className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                  Lugar / Ciudad
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                  Precio de Boleta / Juego
                </label>
                <input
                  type="text"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                  URL Carátula / Imagen Principal
                </label>
                <input
                  type="url"
                  value={coverImage}
                  onChange={(e) => setCoverImage(e.target.value)}
                  className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                Descripción
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-white"
              />
            </div>

            <div className="flex items-center gap-3 p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900">
              <input
                type="checkbox"
                id="edit-upcoming"
                checked={upcoming}
                onChange={(e) => setUpcoming(e.target.checked)}
                className="w-4 h-4 text-amber-600 rounded cursor-pointer"
              />
              <label htmlFor="edit-upcoming" className="text-xs font-bold text-amber-900 dark:text-amber-300 cursor-pointer">
                🔥 Es un "Próximo Estreno" (Se mostrará en la sección de próximos estrenos 2026)
              </label>
            </div>
          </div>

          {/* ── CAMPOS ESPECÍFICOS DE VIDEOJUEGOS ── */}
          {category === "games" && (
            <div className="p-5 bg-amber-50/50 dark:bg-amber-950/20 border-2 border-amber-500/30 rounded-2xl space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                    <span>🎮</span> Configuración Específica de Videojuego
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Edita el carrusel de 5 fotos (independiente de la portada), trailer y personajes con sus frases de voz.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                    ID Trailer de YouTube
                  </label>
                  <input
                    type="text"
                    value={youtubeTrailerId}
                    onChange={(e) => setYoutubeTrailerId(e.target.value)}
                    placeholder="TSmJEZoVHTk"
                    className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                    Precio Físico (Cartucho Switch 2)
                  </label>
                  <input
                    type="text"
                    value={pricePhysical}
                    onChange={(e) => setPricePhysical(e.target.value)}
                    placeholder="$69.99 USD / 69,99 €"
                    className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm"
                  />
                </div>
              </div>

              {/* CARRUSEL DE 5 IMÁGENES (Aparte de la carátula) */}
              <div className="space-y-3">
                <label className="block text-xs font-black uppercase text-amber-700 dark:text-amber-300">
                  🖼️ Carrusel de 5 Imágenes del Juego (Independientes de la Portada Principal):
                </label>
                <div className="grid grid-cols-1 gap-2.5">
                  {carouselImages.map((imgUrl, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <span className="text-xs font-bold w-6 text-gray-400">#{idx + 1}</span>
                      <input
                        type="url"
                        value={imgUrl}
                        onChange={(e) => handleCarouselChange(idx, e.target.value)}
                        placeholder={`URL de la captura ${idx + 1}`}
                        className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg text-xs bg-white dark:bg-gray-900"
                      />
                      {imgUrl && (
                        <img
                          src={imgUrl}
                          alt="preview"
                          className="w-10 h-7 object-cover rounded border"
                        />
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* PERSONAJES CON FRASES AL HACER CLICK */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-black uppercase text-amber-700 dark:text-amber-300">
                    🗡️ Personajes Principales (Foto circular y Frase de Voz interactiva):
                  </label>
                  <button
                    type="button"
                    onClick={addGameCharacter}
                    className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold rounded-lg cursor-pointer"
                  >
                    + Añadir Personaje
                  </button>
                </div>

                <div className="space-y-3">
                  {gameCharacters.map((char, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-amber-600">Personaje #{idx + 1}</span>
                        {gameCharacters.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeGameCharacter(idx)}
                            className="text-[11px] text-red-500 hover:underline"
                          >
                            Eliminar
                          </button>
                        )}
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <div>
                          <input
                            type="text"
                            placeholder="Nombre del personaje (ej. Link)"
                            value={char.name}
                            onChange={(e) => handleGameCharacterChange(idx, "name", e.target.value)}
                            className="w-full px-2.5 py-1.5 border rounded-lg text-xs"
                          />
                        </div>
                        <div>
                          <input
                            type="url"
                            placeholder="URL foto circular"
                            value={char.imageUrl}
                            onChange={(e) => handleGameCharacterChange(idx, "imageUrl", e.target.value)}
                            className="w-full px-2.5 py-1.5 border rounded-lg text-xs"
                          />
                        </div>
                        <div>
                          <input
                            type="text"
                            placeholder="Frase / Voz al click (ej. ¡Hyaaah!)"
                            value={char.phrase}
                            onChange={(e) => handleGameCharacterChange(idx, "phrase", e.target.value)}
                            className="w-full px-2.5 py-1.5 border rounded-lg text-xs"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ── CAMPOS ESPECÍFICOS DE MÚSICA ── */}
          {category === "music" && (
            <div className="p-5 bg-blue-50/50 dark:bg-blue-950/20 border-2 border-blue-500/30 rounded-2xl space-y-4">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <span>🎵</span> Configuración Específica de Música
              </h3>

              <div>
                <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                  ID Video de YouTube
                </label>
                <input
                  type="text"
                  value={musicYoutubeId}
                  onChange={(e) => setMusicYoutubeId(e.target.value)}
                  placeholder="eVTXPUF4Oz4"
                  className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm"
                />
              </div>

              {/* INTEGRANTES DE LA BANDA */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-black uppercase text-blue-700 dark:text-blue-300">
                    🎸 Integrantes de la Banda / Músicos:
                  </label>
                  <button
                    type="button"
                    onClick={addBandMember}
                    className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg cursor-pointer"
                  >
                    + Añadir Músico
                  </button>
                </div>

                <div className="space-y-2.5">
                  {bandMembers.map((member, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl flex flex-col sm:flex-row items-center gap-2"
                    >
                      <input
                        type="text"
                        placeholder="Nombre (ej. Chester Bennington)"
                        value={member.name}
                        onChange={(e) => handleBandMemberChange(idx, "name", e.target.value)}
                        className="flex-1 px-2.5 py-1.5 border rounded-lg text-xs"
                      />
                      <input
                        type="text"
                        placeholder="Rol (ej. Voz Principal, Batería)"
                        value={member.role}
                        onChange={(e) => handleBandMemberChange(idx, "role", e.target.value)}
                        className="flex-1 px-2.5 py-1.5 border rounded-lg text-xs"
                      />
                      <input
                        type="url"
                        placeholder="URL Foto"
                        value={member.imageUrl}
                        onChange={(e) => handleBandMemberChange(idx, "imageUrl", e.target.value)}
                        className="flex-1 px-2.5 py-1.5 border rounded-lg text-xs"
                      />
                      {bandMembers.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeBandMember(idx)}
                          className="text-xs text-red-500 px-2 py-1"
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ── CAMPOS ESPECÍFICOS DE TEATRO ── */}
          {category === "theatre" && (
            <div className="p-5 bg-purple-50/50 dark:bg-purple-950/20 border-2 border-purple-500/30 rounded-2xl space-y-4">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <span>🎭</span> Configuración Específica de Teatro
              </h3>

              <div>
                <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                  URL Cartel de la Obra (Afiche vertical)
                </label>
                <input
                  type="url"
                  value={theaterImage}
                  onChange={(e) => setTheaterImage(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-sm"
                />
              </div>

              {/* PERSONAJES PRINCIPALES Y ACTORES */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-black uppercase text-purple-700 dark:text-purple-300">
                    👥 Personajes Principales y Actores que los Representan:
                  </label>
                  <button
                    type="button"
                    onClick={addTheaterCharacter}
                    className="px-2.5 py-1 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-lg cursor-pointer"
                  >
                    + Añadir Personaje
                  </button>
                </div>

                <div className="space-y-2.5">
                  {theaterCharacters.map((char, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl flex flex-col sm:flex-row items-center gap-2"
                    >
                      <input
                        type="text"
                        placeholder="Personaje (ej. Romeo Montesco)"
                        value={char.name}
                        onChange={(e) => handleTheaterCharacterChange(idx, "name", e.target.value)}
                        className="flex-1 px-2.5 py-1.5 border rounded-lg text-xs"
                      />
                      <input
                        type="text"
                        placeholder="Actor / Actriz (ej. Carlos Rivera)"
                        value={char.actor}
                        onChange={(e) => handleTheaterCharacterChange(idx, "actor", e.target.value)}
                        className="flex-1 px-2.5 py-1.5 border rounded-lg text-xs"
                      />
                      <input
                        type="url"
                        placeholder="URL Foto del actor"
                        value={char.imageUrl}
                        onChange={(e) => handleTheaterCharacterChange(idx, "imageUrl", e.target.value)}
                        className="flex-1 px-2.5 py-1.5 border rounded-lg text-xs"
                      />
                      {theaterCharacters.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeTheaterCharacter(idx)}
                          className="text-xs text-red-500 px-2 py-1"
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ── CAMPOS ESPECÍFICOS DE FÚTBOL ── */}
          {category === "football" && (
            <div className="p-5 bg-emerald-50/50 dark:bg-emerald-950/20 border-2 border-emerald-500/30 rounded-2xl space-y-6">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <span>⚽</span> Configuración Específica del Partido de Fútbol
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                    Estadio donde Juegan
                  </label>
                  <input
                    type="text"
                    value={stadium}
                    onChange={(e) => setStadium(e.target.value)}
                    placeholder="Estadio La Independencia (Tunja)"
                    className="w-full px-3 py-2 border rounded-xl text-xs bg-white dark:bg-gray-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                    Hora del Encuentro
                  </label>
                  <input
                    type="text"
                    value={matchTime}
                    onChange={(e) => setMatchTime(e.target.value)}
                    placeholder="6:10 PM / 8:00 PM"
                    className="w-full px-3 py-2 border rounded-xl text-xs bg-white dark:bg-gray-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase text-gray-600 dark:text-gray-400 mb-1">
                    YouTube Stream Directo
                  </label>
                  <input
                    type="text"
                    value={youtubeStreamId}
                    onChange={(e) => setYoutubeStreamId(e.target.value)}
                    placeholder="live_stream_id"
                    className="w-full px-3 py-2 border rounded-xl text-xs bg-white dark:bg-gray-900"
                  />
                </div>
              </div>

              {/* EQUIPO LOCAL */}
              <div className="p-4 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl space-y-3">
                <span className="text-xs font-black uppercase text-blue-600 dark:text-blue-400">
                  🛡️ Equipo Local (Totalmente a la Izquierda)
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Nombre del Equipo Local (ej. Boyacá Chicó FC)"
                    value={homeTeam.name}
                    onChange={(e) => setHomeTeam({ ...homeTeam, name: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                  <input
                    type="url"
                    placeholder="URL Escudo / Logo Local"
                    value={homeTeam.logoUrl}
                    onChange={(e) => setHomeTeam({ ...homeTeam, logoUrl: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Nombre del Director Técnico"
                    value={homeTeam.coach}
                    onChange={(e) => setHomeTeam({ ...homeTeam, coach: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                  <input
                    type="url"
                    placeholder="URL Foto del Director Técnico"
                    value={homeTeam.coachImageUrl}
                    onChange={(e) => setHomeTeam({ ...homeTeam, coachImageUrl: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Nombre del Capitán de Campo"
                    value={homeTeam.captain}
                    onChange={(e) => setHomeTeam({ ...homeTeam, captain: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                  <input
                    type="url"
                    placeholder="URL Foto del Capitán"
                    value={homeTeam.captainImageUrl}
                    onChange={(e) => setHomeTeam({ ...homeTeam, captainImageUrl: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                </div>
              </div>

              {/* EQUIPO VISITANTE */}
              <div className="p-4 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl space-y-3">
                <span className="text-xs font-black uppercase text-amber-600 dark:text-amber-400">
                  ⚔️ Equipo Visitante (Totalmente a la Derecha)
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Nombre del Equipo Visitante (ej. Deportivo Pasto)"
                    value={awayTeam.name}
                    onChange={(e) => setAwayTeam({ ...awayTeam, name: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                  <input
                    type="url"
                    placeholder="URL Escudo / Logo Visitante"
                    value={awayTeam.logoUrl}
                    onChange={(e) => setAwayTeam({ ...awayTeam, logoUrl: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Nombre del Director Técnico"
                    value={awayTeam.coach}
                    onChange={(e) => setAwayTeam({ ...awayTeam, coach: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                  <input
                    type="url"
                    placeholder="URL Foto del Director Técnico"
                    value={awayTeam.coachImageUrl}
                    onChange={(e) => setAwayTeam({ ...awayTeam, coachImageUrl: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Nombre del Capitán de Campo"
                    value={awayTeam.captain}
                    onChange={(e) => setAwayTeam({ ...awayTeam, captain: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                  <input
                    type="url"
                    placeholder="URL Foto del Capitán"
                    value={awayTeam.captainImageUrl}
                    onChange={(e) => setAwayTeam({ ...awayTeam, captainImageUrl: e.target.value })}
                    className="px-3 py-2 border rounded-lg text-xs"
                  />
                </div>
              </div>
            </div>
          )}

          <div className="pt-4 flex items-center justify-end gap-3 border-t border-gray-100 dark:border-gray-800">
            <Link
              href="/admin/dashboard"
              className="px-4 py-2.5 border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 text-sm font-semibold rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            >
              Cancelar
            </Link>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm rounded-xl shadow-md transition-colors cursor-pointer"
            >
              {loading ? "Guardando..." : "Guardar Cambios del Evento"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
