import { NextResponse } from "next/server";
import { cookies } from "next/headers";

export async function POST(request: Request) {
  try {
    const { email, password, role: requestedRole } = await request.json();

    if (!email || !password) {
      return NextResponse.json(
        { message: "Por favor proporciona correo y contraseña" },
        { status: 400 }
      );
    }

    // Determinamos rol: si se solicitó explícitamente o si el correo contiene 'admin'
    const role = requestedRole || (email.toLowerCase().includes("admin") ? "admin" : "user");
    const userName = email.split("@")[0] || "Usuario";
    const token = `session_${role}_${Date.now()}`;

    const cookieStore = await cookies();

    // Guardamos cookie token
    cookieStore.set({
      name: "token",
      value: token,
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 7, // 1 semana
    });

    // Guardamos cookie role (accesible para middleware y UI)
    cookieStore.set({
      name: "role",
      value: role,
      httpOnly: false,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
    });

    // Guardamos nombre de usuario para saludo personalizado
    cookieStore.set({
      name: "user_name",
      value: userName,
      httpOnly: false,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
    });

    return NextResponse.json(
      {
        message: "Inicio de sesión exitoso",
        role,
        userName,
        redirectUrl: role === "admin" ? "/admin/dashboard" : "/user/dashboard",
      },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      { message: "Error al procesar la solicitud de inicio de sesión" },
      { status: 500 }
    );
  }
}