import { NextResponse } from "next/server";
import { cookies } from "next/headers";

async function clearAuthCookies() {
  const cookieStore = await cookies();
  cookieStore.delete("token");
  cookieStore.delete("role");
  cookieStore.delete("user_name");
}

export async function POST(request: Request) {
  await clearAuthCookies();
  const url = new URL("/", request.url);
  return NextResponse.redirect(url, { status: 303 });
}

export async function GET(request: Request) {
  await clearAuthCookies();
  const url = new URL("/", request.url);
  return NextResponse.redirect(url, { status: 303 });
}

