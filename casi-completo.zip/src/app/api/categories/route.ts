import { NextResponse } from "next/server";
import { categoriesData, addCategory } from "@/data/categories";
import { cookies } from "next/headers";

export async function GET() {
  return NextResponse.json(categoriesData);
}

export async function POST(request: Request) {
  const cookieStore = await cookies();
  const role = cookieStore.get("role")?.value;

  if (role !== "admin") {
    return NextResponse.json({ message: "No autorizado. Solo administradores pueden crear categorías." }, { status: 403 });
  }

  try {
    const body = await request.json();
    const { name, slug, description, icon } = body;

    if (!name || !slug) {
      return NextResponse.json({ message: "El nombre y el slug son obligatorios" }, { status: 400 });
    }

    const newCategory = {
      id: slug.toLowerCase().trim().replace(/\s+/g, "-"),
      name,
      slug: slug.toLowerCase().trim().replace(/\s+/g, "-"),
      description: description || "",
      icon: icon || "📁",
    };

    addCategory(newCategory);

    return NextResponse.json({ message: "Categoría creada exitosamente", category: newCategory }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ message: "Error al procesar la solicitud" }, { status: 500 });
  }
}

