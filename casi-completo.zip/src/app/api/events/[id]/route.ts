import { NextResponse } from "next/server";
import { eventsData, updateEvent, deleteEvent } from "@/data/events";
import { cookies } from "next/headers";

interface RouteParams {
  params: Promise<{ id: string }>;
}

export async function GET(request: Request, { params }: RouteParams) {
  const { id } = await params;
  const event = eventsData.find((e) => e.id === id);
  if (!event) {
    return NextResponse.json({ message: "Evento no encontrado" }, { status: 404 });
  }
  return NextResponse.json(event);
}

export async function PUT(request: Request, { params }: RouteParams) {
  const cookieStore = await cookies();
  const role = cookieStore.get("role")?.value;

  if (role !== "admin") {
    return NextResponse.json({ message: "No autorizado" }, { status: 403 });
  }

  const { id } = await params;
  try {
    const body = await request.json();
    const success = updateEvent(id, body);
    if (!success) {
      return NextResponse.json({ message: "Evento no encontrado" }, { status: 404 });
    }
    return NextResponse.json({ message: "Evento actualizado correctamente" });
  } catch (error) {
    return NextResponse.json({ message: "Error al actualizar evento" }, { status: 500 });
  }
}

export async function DELETE(request: Request, { params }: RouteParams) {
  const cookieStore = await cookies();
  const role = cookieStore.get("role")?.value;

  if (role !== "admin") {
    return NextResponse.json({ message: "No autorizado" }, { status: 403 });
  }

  const { id } = await params;
  const success = deleteEvent(id);
  if (!success) {
    return NextResponse.json({ message: "Evento no encontrado" }, { status: 404 });
  }
  return NextResponse.json({ message: "Evento eliminado correctamente" });
}

