"use client";

import { useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";

function LoginForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<"user" | "admin">("user");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectTarget = searchParams.get("redirect");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, role }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.message || "Credenciales inválidas");
      }

      // Si había una redirección pendiente (ej. intento de ver un evento), vamos allá
      if (redirectTarget) {
        router.push(redirectTarget);
        router.refresh();
        return;
      }

      // Redirigir según el rol
      if (data.role === "admin") {
        router.push("/admin/dashboard");
      } else {
        router.push("/user/dashboard");
      }
      router.refresh();
    } catch (err: any) {
      setError(err.message || "Ocurrió un error al iniciar sesión");
    } finally {
      setLoading(false);
    }
  };

  const setFastLogin = (fastEmail: string, fastPass: string, fastRole: "user" | "admin") => {
    setEmail(fastEmail);
    setPassword(fastPass);
    setRole(fastRole);
    setError("");
  };

  return (
    <div className="w-full max-w-md p-8 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-xl">
      <div className="text-center mb-6">
        <span className="text-4xl">🎪</span>
        <h1 className="text-2xl font-black text-gray-900 dark:text-white mt-2">
          Iniciar Sesión
        </h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
          {redirectTarget
            ? "🔒 Inicia sesión para acceder a este evento exclusivo"
            : "Accede al catálogo global de eventos y estrenos"}
        </p>
      </div>

      {/* Accesos rápidos de demostración */}
      <div className="mb-6 p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-dashed border-gray-300 dark:border-gray-700">
        <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2 text-center uppercase tracking-wider">
          Probar con 1 click:
        </p>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => setFastLogin("admin@eventos.com", "admin123", "admin")}
            className="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-purple-100 hover:bg-purple-200 text-purple-800 dark:bg-purple-950 dark:hover:bg-purple-900 dark:text-purple-300 transition-colors text-center cursor-pointer"
          >
            👑 Rol Admin
          </button>
          <button
            type="button"
            onClick={() => setFastLogin("usuario@eventos.com", "user123", "user")}
            className="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-blue-100 hover:bg-blue-200 text-blue-800 dark:bg-blue-950 dark:hover:bg-blue-900 dark:text-blue-300 transition-colors text-center cursor-pointer"
          >
            👤 Rol Usuario
          </button>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-3 text-xs bg-red-100 text-red-600 dark:bg-red-950/80 dark:text-red-400 rounded-lg border border-red-200 dark:border-red-900">
          {error}
        </div>
      )}

      <form onSubmit={handleLogin} className="space-y-4">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 dark:text-gray-400 mb-1">
            Rol de Acceso
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setRole("user")}
              className={`py-2 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                role === "user"
                  ? "bg-blue-600 text-white border-blue-600 shadow-xs"
                  : "border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
              }`}
            >
              👤 Usuario
            </button>
            <button
              type="button"
              onClick={() => setRole("admin")}
              className={`py-2 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                role === "admin"
                  ? "bg-purple-600 text-white border-purple-600 shadow-xs"
                  : "border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
              }`}
            >
              👑 Administrador
            </button>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold uppercase text-gray-600 dark:text-gray-400 mb-1">
            Correo Electrónico
          </label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="tu@correo.com"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold uppercase text-gray-600 dark:text-gray-400 mb-1">
            Contraseña
          </label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl bg-transparent text-gray-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="••••••••"
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full py-3 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl font-bold text-sm transition-all shadow-md hover:shadow-lg cursor-pointer"
        >
          {loading ? "Verificando credenciales..." : `Entrar como ${role === "admin" ? "Administrador" : "Usuario"}`}
        </button>
      </form>

      <p className="text-xs text-center text-gray-500 dark:text-gray-400 mt-6">
        ¿No tienes cuenta?{" "}
        <Link href="/register" className="text-blue-500 hover:underline font-semibold">
          Regístrate aquí
        </Link>
      </p>
    </div>
  );
}

export default function LoginPage() {
  return (
    <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center p-6 bg-gray-50 dark:bg-gray-950">
      <Suspense fallback={<div className="text-sm text-gray-500">Cargando formulario...</div>}>
        <LoginForm />
      </Suspense>
    </div>
  );
}