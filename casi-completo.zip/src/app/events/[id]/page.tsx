import Link from "next/link";
import { cookies } from "next/headers";
import { getEventById, type EventItem } from "@/data/events";
import GameInteractiveDetail from "@/components/events/GameInteractiveDetail";
import FootballDetail from "@/components/events/FootballDetail";
import TheaterDetail from "@/components/events/TheaterDetail";
import MusicDetail from "@/components/events/MusicDetail";

interface EventDetailPageProps {
  params: Promise<{ id: string }>;
}

export default async function EventDetailPage({ params }: EventDetailPageProps) {
  const { id } = await params;
  const event = getEventById(id);

  const cookieStore = await cookies();
  const token = cookieStore.get("token")?.value;
  const role = cookieStore.get("role")?.value || "user";
  const isAdmin = token && role === "admin";

  // Si el evento no existe, mostramos mensaje amigable y enlaces
  if (!event) {
    return (
      <div className="mx-auto max-w-2xl p-8 my-12 text-center bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-md">
        <span className="text-5xl">🔍</span>
        <h1 className="text-2xl font-black text-gray-900 dark:text-white mt-4 mb-2">
          Evento no encontrado
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mb-6 text-sm">
          El evento que buscas no existe o ha sido modificado.
        </p>
        <div className="flex justify-center gap-3">
          <Link
            href="/events"
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-semibold transition-colors"
          >
            Ver todos los eventos
          </Link>
          <Link
            href="/"
            className="px-4 py-2 border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 rounded-xl text-sm font-semibold transition-colors"
          >
            Volver al Inicio
          </Link>
        </div>
      </div>
    );
  }

  // ── REGLA SOLICITADA POR EL USUARIO: Si no está logueado, debe pedir login para ingresar al evento ──
  if (!token) {
    return (
      <div className="mx-auto max-w-lg p-8 my-16 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl shadow-2xl text-center animate-fade-in">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-amber-100 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 flex items-center justify-center text-3xl mb-4 shadow-sm">
          🔒
        </div>
        <h2 className="text-2xl font-black text-gray-900 dark:text-white">
          Contenido Exclusivo para Miembros
        </h2>
        <p className="text-sm text-gray-600 dark:text-gray-400 mt-2 leading-relaxed">
          Para ver el contenido completo de <strong>{event.title}</strong>, reproducciones en vivo, trailers interactivos y compra de boletos, necesitas iniciar sesión con tu cuenta.
        </p>

        <div className="mt-6 flex flex-col sm:flex-row justify-center gap-3">
          <Link
            href={`/login?redirect=/events/${event.id}`}
            className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-extrabold shadow-md hover:shadow-lg transition-all"
          >
            Iniciar Sesión
          </Link>
          <Link
            href="/register"
            className="px-6 py-3 border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-xl text-sm font-bold transition-colors"
          >
            Crear Cuenta Gratis
          </Link>
        </div>

        <div className="mt-6 pt-6 border-t border-gray-100 dark:border-gray-800">
          <Link href="/events" className="text-xs text-blue-500 hover:underline">
            &larr; Volver al catálogo de eventos
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      {/* Barra de navegación superior / acciones de Admin */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <Link
          href="/events"
          className="text-xs sm:text-sm font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
        >
          &larr; Volver a Todos los Eventos
        </Link>

        {isAdmin && (
          <div className="flex items-center gap-2">
            <span className="text-xs bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 font-bold px-2.5 py-1 rounded-full">
              👑 Modo Administrador
            </span>
            <Link
              href={`/admin/events/${event.id}/edit`}
              className="text-xs font-bold px-3 py-1.5 rounded-lg bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 transition-colors"
            >
              ✏️ Editar
            </Link>
          </div>
        )}
      </div>

      {/* Renderizado condicional según la categoría del evento */}
      {event.category === "games" && (
        <GameInteractiveDetail game={event} />
      )}

      {event.category === "football" && (
        <FootballDetail match={event} />
      )}

      {event.category === "theatre" && (
        <TheaterDetail theater={event} />
      )}

      {event.category === "music" && (
        <MusicDetail event={event} />
      )}
    </div>
  );
}
