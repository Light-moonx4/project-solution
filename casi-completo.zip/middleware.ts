import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export async function middleware(request: NextRequest) {
  const token = request.cookies.get("token")?.value;
  const role = request.cookies.get("role")?.value || "user";
  const { pathname } = request.nextUrl;

  // Rutas que requieren autenticación
  if (!token && (pathname.startsWith("/admin") || pathname.startsWith("/user"))) {
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("redirect", pathname);
    return NextResponse.redirect(loginUrl);
  }

  // Rutas exclusivas para administradores
  if (pathname.startsWith("/admin")) {
    if (role !== "admin") {
      // Si el usuario no es admin, lo mandamos a su panel de usuario
      return NextResponse.redirect(new URL("/user/dashboard", request.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*", "/user/:path*"],
};